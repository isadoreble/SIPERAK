<?php

namespace App\Models;

use CodeIgniter\Model;

class BukuModel extends Model
{
    protected $table = 'buku';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'kode_buku', 'nama_buku', 'penulis', 'penerbit', 'tahun_terbit',
        'kategori_id', 'isbn', 'jumlah_halaman', 'sinopsis', 'sumber_buku',
        'cover', 'lokasi_rak', 'status', 'created_at', 'updated_at'
    ];
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    // Validation rules
    protected $validationRules = [
        'kode_buku' => 'required|min_length[3]|max_length[50]|is_unique[buku.kode_buku,id,{id}]',
        'nama_buku' => 'required|min_length[3]|max_length[200]',
        'penulis' => 'required|min_length[3]|max_length[100]'
    ];
    
    protected $validationMessages = [
        'kode_buku' => [
            'required' => 'Kode buku wajib diisi',
            'min_length' => 'Kode buku minimal 3 karakter',
            'max_length' => 'Kode buku maksimal 50 karakter',
            'is_unique' => 'Kode buku sudah ada'
        ],
        'nama_buku' => [
            'required' => 'Nama buku wajib diisi',
            'min_length' => 'Nama buku minimal 3 karakter',
            'max_length' => 'Nama buku maksimal 200 karakter'
        ]
    ];
    
    // Get buku dengan kategori
    public function getBukuWithKategori()
    {
        return $this->select('buku.*, kategori.nama_kategori as kategori')
                    ->join('kategori', 'kategori.id = buku.kategori_id', 'left')
                    ->findAll();
    }
    
    // Get buku terpopuler (dipinjam paling banyak)
    public function getBukuPopuler($limit = 5)
    {
        return $this->select('buku.*, COUNT(peminjaman.id) as jumlah_peminjaman')
                    ->join('peminjaman', 'peminjaman.buku_id = buku.id', 'left')
                    ->groupBy('buku.id')
                    ->orderBy('jumlah_peminjaman', 'DESC')
                    ->limit($limit)
                    ->findAll();
    }
}