<?php

namespace App\Models;

use CodeIgniter\Model;

class SiswaModel extends Model
{
    protected $table = 'siswa';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nis', 'nama', 'kelas', 'jenis_kelamin', 'alamat', 'telepon', 'email', 'foto', 'status'];
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    // Validation rules
    protected $validationRules = [
        'nis' => 'required|min_length[5]|max_length[20]|is_unique[siswa.nis,id,{id}]',
        'nama' => 'required|min_length[3]|max_length[100]',
        'kelas' => 'required|min_length[1]|max_length[10]',
        'email' => 'permit_empty|valid_email|is_unique[siswa.email,id,{id}]'
    ];
    
    protected $validationMessages = [
        'nis' => [
            'required' => 'NIS wajib diisi',
            'min_length' => 'NIS minimal 5 karakter',
            'max_length' => 'NIS maksimal 20 karakter',
            'is_unique' => 'NIS sudah terdaftar'
        ],
        'nama' => [
            'required' => 'Nama wajib diisi',
            'min_length' => 'Nama minimal 3 karakter',
            'max_length' => 'Nama maksimal 100 karakter'
        ]
    ];
}