<?php

namespace App\Models;

use CodeIgniter\Model;

class PeminjamanModel extends Model
{
    protected $table            = 'peminjaman';
    protected $primaryKey       = 'id';

    protected $allowedFields = [
        'nis',
        'buku_id',
        'tanggal_pinjam',
        'tanggal_kembali',
        'durasi_hari',
        'status',
        'created_at',
        'updated_at'
    ];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $dateFormat    = 'datetime';

    /*
    =========================
    VALIDATION
    =========================
    */
    protected $validationRules = [
        'nis'            => 'required',
        'buku_id'        => 'required|integer',
        'tanggal_pinjam' => 'required|valid_date',
        'durasi_hari'    => 'required|integer',
        'status'         => 'in_list[Diproses,Disetujui,Ditolak,Terlambat,Kembali]'
    ];

    protected $validationMessages = [
        'nis' => [
            'required' => 'NIS wajib diisi'
        ],
        'buku_id' => [
            'required' => 'Buku wajib dipilih'
        ],
        'status' => [
            'in_list' => 'Status tidak valid'
        ]
    ];

    /*
    =========================
    ADMIN - SEMUA PEMINJAMAN
    =========================
    */
    public function getAllWithDetail()
    {
        return $this->select('
                peminjaman.*,
                buku.nama_buku,
                buku.cover,
                users.nama,
                users.kelas
            ')
            ->join('buku', 'buku.id = peminjaman.buku_id', 'left')
            ->join('users', 'users.nis = peminjaman.nis', 'left')
            ->orderBy('peminjaman.created_at', 'DESC')
            ->findAll();
    }

    /*
    =========================
    SISWA - PINJAMAN SAYA
    =========================
    */
    public function getByNis($nis)
    {
        return $this->select('
                peminjaman.*,
                buku.nama_buku,
                buku.cover
            ')
            ->join('buku', 'buku.id = peminjaman.buku_id', 'left')
            ->where('peminjaman.nis', $nis)
            ->orderBy('peminjaman.created_at', 'DESC')
            ->findAll();
    }

    /*
    =========================
    CEK PINJAMAN AKTIF SISWA
    (Diproses + Disetujui)
    =========================
    */
    public function countPinjamanAktif($nis)
    {
        return $this->where('nis', $nis)
            ->whereIn('status', ['Diproses', 'Disetujui'])
            ->countAllResults();
    }

    /*
    =========================
    CEK SUDAH PINJAM BUKU
    =========================
    */
    public function alreadyBorrowed($nis, $buku_id)
    {
        return $this->where('nis', $nis)
            ->where('buku_id', $buku_id)
            ->whereIn('status', ['Diproses', 'Disetujui'])
            ->first();
    }

    /*
    =========================
    ADMIN - SETUJUI PINJAMAN
    =========================
    */
    public function approve($id)
    {
        return $this->update($id, [
            'status' => 'Disetujui'
        ]);
    }

    /*
    =========================
    ADMIN - TOLAK PINJAMAN
    =========================
    */
    public function reject($id)
    {
        return $this->update($id, [
            'status' => 'Ditolak'
        ]);
    }
}
