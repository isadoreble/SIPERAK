<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Auth::login');

$routes->get('/login', 'Auth::login');
$routes->post('/login', 'Auth::proses');
$routes->get('/logout', 'Auth::logout');

$routes->get('/admin', 'Dashboard::admin');
$routes->get('/petugas', 'Dashboard::petugas');

$routes->get('/auth/hash', 'Auth::hash');
$routes->get('/guru', 'Dashboard::guru');
$routes->get('/siswa', 'Dashboard::siswa');

$routes->get('/buku', 'Buku::index');
$routes->get('/buku/tambah', 'Buku::tambah');
$routes->post('/buku/simpan', 'Buku::simpan');
$routes->get('/buku/edit/(:num)', 'Buku::edit/$1');
$routes->post('/buku/update/(:num)', 'Buku::update/$1');
$routes->get('/buku/hapus/(:num)', 'Buku::hapus/$1');

$routes->get('/dashboard', 'Dashboard::index');
$routes->get('/buku/export/pdf', 'Buku::exportPdf');
$routes->get('/buku/export/excel', 'Buku::exportExcel');

// =======================
// BUKU BOS
// =======================
$routes->get('/buku-bos', 'Buku::bos');
$routes->get('/buku-bos/tambah', 'Buku::tambahBos');
$routes->post('/buku-bos/simpan', 'Buku::simpanBos');

// =======================
// BUKU PERPUSTAKAAN (ASLI)
// =======================
$routes->get('/buku-perpus', 'Buku::perpus');
$routes->get('/buku-perpus/tambah', 'Buku::tambahPerpus');
$routes->post('/buku-perpus/simpan', 'Buku::simpanPerpus');

// =======================
// ✅ TAMBAHAN ALIAS (BIAR TIDAK 404)
// =======================
$routes->get('/buku-perpustakaan', 'Buku::perpustakaan');
$routes->get('/buku-perpustakaan/tambah', 'Buku::tambahPerpustakaan');
$routes->post('/buku-perpustakaan/simpan', 'Buku::simpanPerpustakaan');

// =======================
// ✅ PEMINJAMAN SISTEM
// =======================

// halaman pinjaman siswa
$routes->get('/siswa/pinjaman', 'Dashboard::pinjaman');
$routes->get('/siswa/peminjaman', 'PeminjamanSiswa::index');
$routes->post('/siswa/peminjaman/pinjam', 'PeminjamanSiswa::pinjam');
$routes->get('/siswa/peminjaman/pinjam/(:num)', 'PeminjamanSiswa::pinjam/$1');

// daftar peminjaman admin/petugas
$routes->get('/peminjaman', 'Peminjaman::index');

// simpan peminjaman
$routes->post('/peminjaman/simpan', 'Peminjaman::simpan');

// pengembalian buku
$routes->get('/peminjaman/kembali/(:num)', 'Peminjaman::kembali/$1');

// approve / reject
$routes->get('/peminjaman/setujui/(:num)', 'Peminjaman::setujui/$1');
$routes->get('/peminjaman/tolak/(:num)', 'Peminjaman::tolak/$1');

// update status terlambat
$routes->get('/peminjaman/update-status', 'Peminjaman::updateStatus');

