<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddDurasiToPeminjaman extends Migration
{
    public function up()
    {
        $fields = [
            'durasi_hari' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 7,
                'null' => false,
            ],
        ];

        $this->forge->addColumn('peminjaman', $fields);
    }

    public function down()
    {
        $this->forge->dropColumn('peminjaman', 'durasi_hari');
    }
}
