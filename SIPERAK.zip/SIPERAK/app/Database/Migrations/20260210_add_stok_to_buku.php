<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddStokToBuku extends Migration
{
    public function up()
    {
        $fields = [
            'stok' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 0,
                'null' => false,
            ],
        ];

        $this->forge->addColumn('buku', $fields);
    }

    public function down()
    {
        $this->forge->dropColumn('buku', 'stok');
    }
}
