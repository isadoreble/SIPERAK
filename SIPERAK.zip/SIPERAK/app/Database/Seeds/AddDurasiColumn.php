<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class AddDurasiColumn extends Seeder
{
    public function run()
    {
        $db = \Config\Database::connect();
        
        // Check if column exists before adding
        $fields = $db->getFieldNames('peminjaman');
        if (!in_array('durasi_hari', $fields)) {
            $db->query('ALTER TABLE peminjaman ADD COLUMN durasi_hari INT(11) DEFAULT 7 NOT NULL AFTER tanggal_pinjam');
            echo 'Column durasi_hari added successfully';
        } else {
            echo 'Column durasi_hari already exists';
        }
    }
}
