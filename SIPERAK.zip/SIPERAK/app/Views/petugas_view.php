<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>SIPERAK - Petugas</title>
    <style>
        body {
            margin: 0;
            background: #0d1b2a;
            font-family: Arial, sans-serif;
            color: white;
        }

        header {
            background: #1b263b;
            padding: 15px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            height: 45px;
            margin-right: 15px;
        }

        .logo h1 {
            color: #4da8ff;
            font-size: 22px;
        }

        .logout {
            color: white;
            text-decoration: none;
            background: #ff4d4d;
            padding: 8px 15px;
            border-radius: 5px;
        }

        .hero {
            padding: 40px;
        }

        .row {
            padding: 20px 40px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .card {
            background: #1b263b;
            padding: 20px;
            border-radius: 10px;
            transition: 0.3s;
            cursor: pointer;
            text-align: center;
        }

        .card:hover {
            transform: scale(1.05);
            background: #4da8ff;
            color: black;
        }
    </style>
</head>
<body>

<header>
    <div class="logo">
        <img src="/assets/logo.png">
        <h1>SIPERAK | Petugas</h1>
    </div>
    <a href="/logout" class="logout">Logout</a>
</header>

<div class="hero">
    <h2>Halo, <?= session()->get('nama') ?></h2>
    <p>Dashboard Petugas Perpustakaan</p>
</div>

<div class="row">
    <div class="cards">
        <div class="card">📚 Peminjaman Buku</div>
        <div class="card">🔄 Pengembalian</div>
        <div class="card">👨‍🎓 Data Siswa</div>
    </div>
</div>

</body>
</html>
