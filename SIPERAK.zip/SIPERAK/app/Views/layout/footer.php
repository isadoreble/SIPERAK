<footer class="library-footer">
  <div class="footer-container">

    <!-- BRAND -->
    <div class="footer-brand">
      <img src="<?= base_url('assets/img/logo smansa.png') ?>" class="footer-logo" alt="SIPERAK Logo">
      <h3>
        <span class="system-subtitle">Sistem Informasi Perpustakaan</span>
        <a href="#" class="school-name">SIPERAK</a>
      </h3>
      <p class="brand-desc">
        Perpustakaan Digital SMA Negeri 1 Tanjungpinang
      </p>
    </div>

    <!-- INFO -->
    <div class="footer-info">
      <h4>Informasi Sekolah</h4>
      <ul>
        <li>
          <a href="#">
            <ion-icon name="location-outline"></ion-icon>
            Tanjungpinang, Kepulauan Riau
          </a>
        </li>
        <li>
          <a href="#">
            <ion-icon name="call-outline"></ion-icon>
            (0771) 123456
          </a>
        </li>
        <li>
          <a href="#">
            <ion-icon name="mail-outline"></ion-icon>
            sman1tpn@gmail.com
          </a>
        </li>
      </ul>
    </div>

    <!-- SERVICES -->
    <div class="footer-services">
      <h4>Layanan</h4>
      <ul>
        <li>📚 Peminjaman Buku</li>
        <li>💻 Perpustakaan Digital</li>
        <li>📖 Buku Pelajaran</li>
        <li>📕 Novel & Cerita</li>
      </ul>
    </div>

    <!-- SOCIAL -->
    <div class="footer-social">
      <h4>Ikuti Kami</h4>
      <div class="social-icons">
        <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
        <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
        <a href="#"><ion-icon name="logo-youtube"></ion-icon></a>
      </div>
    </div>

  </div>

  <div class="footer-bottom">
    © <?= date('Y') ?> SIPERAK - SMA Negeri 1 Tanjungpinang
    <span class="footer-quote">“Membaca adalah jendela dunia”</span>
  </div>
</footer>

<!-- IONICONS -->
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
