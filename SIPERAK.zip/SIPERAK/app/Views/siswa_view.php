<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Siswa SIPERAK</title>
    <!-- Footer CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/Footer.css') ?>">


<style>

/* ===== RESET ===== */
* { box-sizing: border-box; }

body {
    margin: 0;
    background: #f1f4f9;
    font-family: "Segoe UI", sans-serif;
}

/* ===== LAYOUT ===== */
.wrapper {
    display: flex;
    min-height: 100vh;
}

/* ===== SIDEBAR ===== */
.sidebar {
    width: 240px;
    background: linear-gradient(180deg,#0f2a4f,#081a33);
    color: white;
    padding: 20px 15px;
    transition: 0.3s;
}

.sidebar.hide {
    margin-left: -240px;
}

.sidebar .logo {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 30px;
}

.sidebar img {
    width: 45px;
    border-radius: 8px;
}

.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 12px 14px;
    border-radius: 10px;
    margin-bottom: 8px;
    font-size: 14px;
}

.sidebar a:hover,
.sidebar a.active {
    background: rgba(255,255,255,0.15);
}

/* ===== MAIN ===== */
.main {
    flex: 1;
    display: flex;
    flex-direction: column;
}

/* ===== TOPBAR ===== */
.topbar {
    background: linear-gradient(135deg,#1e3c72,#2a5298);
    color: white;
    padding: 14px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.top-left {
    display: flex;
    align-items: center;
    gap: 15px;
}

.menu-btn {
    font-size: 22px;
    cursor: pointer;
    background: rgba(255,255,255,0.15);
    padding: 6px 12px;
    border-radius: 8px;
}

/* ===== CONTENT ===== */
.content {
    padding: 25px;
}

/* ===== HERO ===== */
.hero {
    background: linear-gradient(135deg,#1e3c72,#2a5298);
    color: white;
    padding: 30px;
    border-radius: 16px;
    margin-bottom: 25px;
}

.hero span {
    color: #FFD700;
}

/* ===== INFO GRID ===== */
.info {
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(260px,1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.card {
    background: white;
    padding: 22px;
    border-radius: 14px;
    box-shadow: 0 6px 16px rgba(0,0,0,0.08);
}

.card h3 {
    margin: 0;
    font-size: 15px;
    color: #2a5298;
}

.card p {
    font-size: 22px;
    font-weight: bold;
}

/* ===== SECTION ===== */
.section {
    background: white;
    padding: 22px;
    border-radius: 14px;
    box-shadow: 0 6px 16px rgba(0,0,0,0.08);
    margin-bottom: 20px;
}

/* ===== BOOK GRID ===== */
.books {
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(160px,1fr));
    gap: 18px;
    margin-top: 15px;
}

.book {
    background: #f8fafc;
    border-radius: 12px;
    padding: 12px;
    text-align: center;
}

.book img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 8px;
}

.status {
    font-size: 12px;
    padding: 4px 8px;
    border-radius: 6px;
    display: inline-block;
    margin-top: 6px;
    font-weight: bold;
}

.diproses { background: #f39c12; color: white; }
.disetujui { background: #27ae60; color: white; }
.ditolak { background: #c0392b; color: white; }
.terlambat { background: #e74c3c; color: white; }
.kembali { background: #16a085; color: white; }

</style>
</head>

<body>

<?php
$pinjaman = $pinjaman ?? [];
$today = date('Y-m-d');

$jatuhTempo = 0;

foreach ($pinjaman as $p) {
    if ($p['status'] == 'dipinjam' && $p['tanggal_kembali'] >= $today) {
        $jatuhTempo++;
    }
}
?>

<div class="wrapper">

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="<?= base_url('assets/img/logo smansa.png') ?>" alt="SIPERAK Logo">
        <span>SIPERAK</span>
    </div>

    <a href="<?= base_url('/siswa') ?>" class="active">🏠 Dashboard</a>
    <a href="<?= base_url('/siswa/peminjaman') ?>">📖 Peminjaman</a>
    <a href="<?= base_url('/siswa/pinjaman') ?>">📚 Pinjaman Saya</a>
    <a href="<?= base_url('/logout') ?>">🚪 Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<!-- TOPBAR -->
<div class="topbar">

<div class="top-left">
    <div class="menu-btn" onclick="toggleSidebar()">☰</div>
    <h2>Dashboard Siswa</h2>
</div>

<div><?= role_get('siswa', 'nama', session()->get('nama')) ?></div>

</div>

<!-- CONTENT -->
<div class="content">

<div class="hero">
    <h1>Selamat Datang, <span><?= role_get('siswa', 'nama', session()->get('nama')) ?></span></h1>
    <p>
        NIS: <?= role_get('siswa', 'nis', session()->get('nis')) ?? '-' ?>
        Kelas: <?= role_get('siswa', 'kelas', session()->get('kelas')) ?>
    </p>
</div>

<div class="info">

<div class="card">
<h3>📚 Buku Dipinjam</h3>
<p><?= count($pinjaman) ?> Buku</p>
</div>

<div class="card">
<h3>⏳ Jatuh Tempo</h3>
<p><?= $jatuhTempo ?> Buku</p>
</div>

<div class="card">
<h3>⭐ Status</h3>
<p>Aktif</p>
</div>

</div>

<!-- PINJAMAN SISWA -->
<div class="section">
<h3>Pinjaman Saya</h3>

<div class="books">

<?php if(empty($pinjaman)): ?>

<p>Tidak ada pinjaman.</p>

<?php else: ?>

<?php foreach($pinjaman as $p):

$status_lower = strtolower($p['status']);
$statusClass = 'diproses'; // default

if ($status_lower == 'disetujui') $statusClass = 'disetujui';
elseif ($status_lower == 'kembali') $statusClass = 'kembali';
elseif ($status_lower == 'ditolak') $statusClass = 'ditolak';
elseif ($status_lower == 'diproses') $statusClass = 'diproses';
elseif ($p['tanggal_kembali'] && $p['tanggal_kembali'] < $today && $status_lower == 'disetujui') $statusClass = 'terlambat';

?>

<div class="book">
<img src="<?= $p['cover'] ? base_url('uploads/'.$p['cover']) : base_url('assets/img/placeholder.png') ?>">
<b><?= $p['nama_buku'] ?></b>
<br>
<span class="status <?= $statusClass ?>">
<?= esc($p['status']) ?>
</span>
<br>
<small><?php if($p['tanggal_kembali']): ?>Kembali: <?= $p['tanggal_kembali'] ?><?php else: ?>Menunggu Persetujuan<?php endif; ?></small>
</div>

<?php endforeach; ?>

<?php endif; ?>

</div>
</div>

<!-- REKOMENDASI -->
<div class="section">
<h3>Buku Rekomendasi</h3>

<div class="books">

<div class="book">
<img src="<?= base_url('assets/img/Laskar Pelangi.jpg') ?>">
<span>Laskar Pelangi</span>
</div>

<div class="book">
<img src="<?= base_url('assets/img/Laut Bercerita.jpg') ?>">
<span>Laut Bercerita</span>
</div>

<div class="book">
<img src="<?= base_url('assets/img/APOLAR.jpg') ?>">
<span>APOLAR</span>
</div>

</div>
</div>

</div>
</div>
</div>


<script>
function toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("hide");
}
</script>

<?= $this->include('layout/footer') ?>

</body>
</html>
