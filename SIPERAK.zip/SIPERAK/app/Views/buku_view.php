<?= $this->extend('admin_layout') ?>
<?= $this->section('content') ?>

<!-- ===== TAMBAHAN WRAPPER KONTEN ===== -->
<div class="content-wrapper">

<h2 class="page-title">
    <ion-icon name="book-outline"></ion-icon>
    Data Buku Perpustakaan
</h2>

<!-- ===== TAMBAHAN TOOLBAR ===== -->
<div class="toolbar">
    <a href="<?= base_url('/buku/tambah') ?>" class="btn btn-primary">
        <ion-icon name="add-circle-outline"></ion-icon>
        Tambah Buku
    </a>

    <!-- SEARCH BOX -->
    <input 
        type="text" 
        id="search" 
        placeholder="Cari buku..."
        class="search-box"
    >
</div>

<!-- ===== TAMBAHAN TABLE WRAPPER (RESPONSIVE) ===== -->
<div class="table-wrapper">

<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>Cover</th>
            <th>Kode Buku</th>
            <th>Nama Buku</th>
            <th>Kategori</th>
            <th>Aksi</th>
        </tr>
    </thead>

    <tbody>
    <?php if(empty($buku)): ?>
        <!-- ===== TAMBAHAN JIKA DATA KOSONG ===== -->
        <tr>
            <td colspan="6" class="empty-data">
                <ion-icon name="alert-circle-outline"></ion-icon>
                Belum ada data buku
            </td>
        </tr>
    <?php else: ?>
    <?php $no=1; foreach($buku as $b): ?>
        <tr>
            <td><?= $no++ ?></td>

            <td>
                <?php if(!empty($b['cover'])): ?>
                    <img 
                        src="<?= base_url('uploads/'.$b['cover']) ?>" 
                        width="50"
                        class="cover-img"
                    >
                <?php else: ?>
                    <span class="no-image">No Image</span>
                <?php endif; ?>
            </td>

            <td><?= esc($b['kode_buku']) ?></td>
            <td><?= esc($b['nama_buku']) ?></td>
            <td><?= esc($b['kategori']) ?></td>

            <td class="aksi">
                <a href="<?= base_url('/buku/edit/'.$b['id']) ?>" class="btn btn-edit" title="Edit">
                    <ion-icon name="create-outline"></ion-icon>
                </a>

                <a 
                    href="<?= base_url('/buku/hapus/'.$b['id']) ?>" 
                    class="btn btn-delete"
                    onclick="return confirm('Yakin ingin menghapus buku ini?')"
                    title="Hapus"
                >
                    <ion-icon name="trash-outline"></ion-icon>
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>

</div>
</div>
<!-- ===== END WRAPPER ===== -->

<!-- LIVE SEARCH -->
<script>
document.getElementById("search").addEventListener("keyup", function() {
    let value = this.value.toLowerCase();
    document.querySelectorAll(".table tbody tr").forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(value)
            ? ""
            : "none";
    });
});
</script>

<?= $this->endSection() ?>
