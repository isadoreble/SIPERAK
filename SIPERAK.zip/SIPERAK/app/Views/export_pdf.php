<h2>Data Buku Perpustakaan SIPERAK</h2>
<hr>
<table border="1" width="100%">
    <tr>
        <th>Kode Buku</th>
        <th>Nama Buku</th>
        <th>Kategori</th>
    </tr>
    <?php foreach($buku as $b): ?>
    <tr>
        <td><?= $b['kode_buku'] ?></td>
        <td><?= $b['nama_buku'] ?></td>
        <td><?= $b['kategori'] ?></td>
    </tr>
    <?php endforeach ?>
</table>

<script>
window.print();
</script>
