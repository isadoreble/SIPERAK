<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Buku SIPERAK</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/dashboard.css') ?>">
    <style>
        .section {
            padding: 40px;
        }
        input {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            margin-bottom: 15px;
        }
        .btn {
            padding: 10px 18px;
            border-radius: 10px;
            text-decoration: none;
            background: #1565c0;
            color: white;
            border: none;
            cursor: pointer;
        }
        .btn-danger {
            background: #c62828;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="nav-left">
        <img src="<?= base_url('assets/img/Logo.jpeg') ?>" style="height:40px;margin-right:10px;">
        <h2>SIPERAK</h2>
    </div>
    <div>
        <a href="<?= base_url('/admin') ?>">Dashboard</a>
        <a href="<?= base_url('/buku') ?>">Buku</a>
        <a href="<?= base_url('/logout') ?>">Logout</a>
    </div>
</div>

<!-- FORM -->
<div class="section">
    <h2>✏️ Edit Buku</h2>
    <br>

    <form action="<?= base_url('/buku/update/'.$buku['id']) ?>" method="post">
        <input type="text" name="kode_buku" value="<?= $buku['kode_buku'] ?>" required>
        <input type="text" name="nama_buku" value="<?= $buku['nama_buku'] ?>" required>
        <input type="text" name="kategori" value="<?= $buku['kategori'] ?>" required>

        <br>
        <button class="btn">Update</button>
        <a href="<?= base_url('/buku') ?>" class="btn btn-danger">Kembali</a>
    </form>
</div>

</body>
</html>
