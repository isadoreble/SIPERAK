<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Daftar Buku - Peminjaman</title>
<style>
body{font-family:Segoe UI, sans-serif;background:#f4f6fb;margin:0;padding:20px}
.container{max-width:1100px;margin:0 auto}
.header{display:flex;justify-content:space-between;align-items:center}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px;margin-top:18px}
.card{background:#fff;padding:12px;border-radius:10px;box-shadow:0 6px 18px rgba(0,0,0,0.06);}
.card img{width:100%;height:220px;object-fit:cover;border-radius:6px}
.meta{margin-top:8px}
.meta b{display:block}
.actions{margin-top:10px;display:flex;gap:8px}
.btn{padding:8px 10px;border-radius:8px;text-decoration:none;font-size:14px}
.btn-primary{background:#1e3c72;color:#fff;cursor:pointer;border:none}
.btn-outline{background:#fff;border:1px solid #ddd;color:#333}
.details{margin-top:10px;background:#fafafa;padding:8px;border-radius:6px;font-size:13px;display:none}

/* MODAL */
.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:1000}
.modal.active{display:flex;align-items:center;justify-content:center}
.modal-content{background:#fff;padding:25px;border-radius:10px;box-shadow:0 10px 40px rgba(0,0,0,0.2);max-width:400px}
.modal-content h3{margin-top:0}
.modal-group{margin:15px 0}
.modal-group label{display:block;margin-bottom:5px;font-weight:500}
.modal-group select, .modal-group input{width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:14px}
.modal-buttons{display:flex;gap:10px;margin-top:20px}
.modal-buttons button{flex:1;padding:10px;border-radius:6px;border:none;cursor:pointer;font-weight:500}
.modal-btn-ok{background:#1e3c72;color:#fff}
.modal-btn-batal{background:#ddd;color:#333}
</style>
</head>
<body>
<div class="container">
<div class="header">
<h2>Daftar Buku untuk Peminjaman</h2>
<div><a href="<?= base_url('/siswa') ?>">◀ Kembali ke Dashboard</a></div>
</div>

<!-- FLASH MESSAGE NOTIFICATION -->
<?php if (session()->has('success')): ?>
<div style="background:#d4edda;color:#155724;padding:12px 15px;border-radius:6px;margin-bottom:15px;border:1px solid #c3e6cb;">
    ✅ <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<?php if (session()->has('error')): ?>
<div style="background:#f8d7da;color:#721c24;padding:12px 15px;border-radius:6px;margin-bottom:15px;border:1px solid #f5c6cb;">
    ❌ <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<p>Pilih buku yang ingin Anda pinjam di bawah ini. Klik "Detail" untuk melihat sinopsis lengkap.</p>

<div class="grid">
<?php if (!empty($buku)) : ?>
    <?php foreach ($buku as $b) : ?>
    <div class="card">
        <img src="<?= $b['cover'] ? base_url('uploads/'.$b['cover']) : base_url('assets/img/placeholder.png') ?>" alt="cover">
        <div class="meta">
            <b><?= esc($b['nama_buku']) ?></b>
            <small>Penulis: <?= esc($b['penulis'] ?? '-') ?></small>
            <div>Penerbit: <?= esc($b['penerbit'] ?? '-') ?></div>
        </div>

        <div class="actions">
            <a class="btn btn-outline" href="#" onclick="toggleDetails(<?= $b['id'] ?>);return false;">📖 Detail</a>
            <button class="btn btn-primary" type="button" onclick="openDurasiModal(<?= $b['id'] ?>, '<?= addslashes($b['nama_buku']) ?>'); return false;">📤 Pinjam</button>
        </div>

        <div id="det-<?= $b['id'] ?>" class="details">
            <strong>Sinopsis:</strong>
            <p><?= nl2br(esc($b['sinopsis'] ?? 'Tidak ada sinopsis')) ?></p>
            <p><strong>ISBN:</strong> <?= esc($b['isbn'] ?? '-') ?></p>
            <p><strong>Tahun Terbit:</strong> <?= esc($b['tahun_terbit'] ?? '-') ?></p>
            <p><strong>Lokasi Rak:</strong> <?= esc($b['lokasi_rak'] ?? '-') ?></p>
        </div>
    </div>
    <?php endforeach; ?>
<?php else: ?>
    <div>Tidak ada data buku.</div>
<?php endif; ?>
</div>

</div>

<!-- MODAL PILIH DURASI -->
<div id="durasiModal" class="modal">
    <div class="modal-content">
        <h3>Pilih Durasi Peminjaman</h3>
        <p id="bukuText"></p>
        <form id="peminjamanForm" method="post" action="<?= base_url('/siswa/peminjaman/pinjam') ?>">
            <input type="hidden" name="buku_id" id="bukuId" value="">
            <div class="modal-group">
                <label for="durasi">Durasi Peminjaman:</label>
                <select name="durasi" id="durasi" required>
                    <option value="">-- Pilih Durasi --</option>
                    <option value="7">7 Hari</option>
                    <option value="14">14 Hari</option>
                    <option value="21">21 Hari</option>
                    <option value="30">30 Hari</option>
                </select>
            </div>
            <div class="modal-buttons">
                <button type="button" class="modal-btn-ok" onclick="submitPeminjamanForm(); return false;">Ajukan Peminjaman</button>
                <button type="button" class="modal-btn-batal" onclick="closeDurasiModal()">Batal</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleDetails(id){
    var el = document.getElementById('det-'+id);
    if(!el) return;
    el.style.display = (el.style.display === 'none') ? 'block' : 'none';
}

function openDurasiModal(bukuId, bukuNama){
    console.log('openDurasiModal called with bukuId:', bukuId, 'bukuNama:', bukuNama);
    
    if (!bukuId || bukuId === '' || bukuId === 'undefined') {
        alert('Error: Buku ID tidak valid (' + bukuId + ')');
        return false;
    }
    
    var hiddenInput = document.getElementById('bukuId');
    if (!hiddenInput) {
        alert('Error: Form element tidak ditemukan');
        return false;
    }
    
    hiddenInput.value = parseInt(bukuId); // Pastikan numeric
    console.log('Hidden input set to:', hiddenInput.value);
    
    document.getElementById('bukuText').textContent = 'Buku: ' + bukuNama;
    document.getElementById('durasiModal').classList.add('active');
    return false;
}

function closeDurasiModal(){
    document.getElementById('durasiModal').classList.remove('active');
    document.getElementById('bukuId').value = '';
    document.getElementById('durasi').value = '';
}

function submitPeminjamanForm(){
    var bukuId = document.getElementById('bukuId').value;
    var durasi = document.getElementById('durasi').value;
    
    console.log('submitPeminjamanForm - bukuId:', bukuId, 'durasi:', durasi);
    
    if (!bukuId || bukuId === '' || bukuId === '0') {
        alert('❌ Error: Buku ID tidak valid. Silakan pilih buku terlebih dahulu.');
        return false;
    }
    
    if (!durasi || durasi === '') {
        alert('❌ Error: Silakan pilih durasi peminjaman terlebih dahulu.');
        return false;
    }
    
    // Submit form
    document.getElementById('peminjamanForm').submit();
    return false;
}
</script>
}

document.addEventListener('click', function(e){
    var modal = document.getElementById('durasiModal');
    if(e.target === modal){
        closeDurasiModal();
    }
});
</script>

</body>
</html>
