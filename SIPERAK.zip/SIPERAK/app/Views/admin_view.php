<?= $this->extend('admin_layout') ?>
<?= $this->section('content') ?>

<style>
    /* VARIABLES - BIRU PUTIH GOLD */
    :root {
        --primary-blue: #1a4b8c;
        --secondary-blue: #2d6fb5;
        --light-blue: #e8f2ff;
        --dark-blue: #0d2b5c;
        --navy-blue: #0a1e3c;
        --gold: #d4af37;
        --light-gold: #f4e8c1;
        --dark-gold: #b8941f;
        --white: #ffffff;
        --light-gray: #f8f9fa;
        --medium-gray: #e9ecef;
        --dark-gray: #333333;
        --success: #2e7d32;
        --warning: #ff8f00;
        --danger: #c62828;
    }

    /* GRID SYSTEM */
    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        margin: 25px 0;
    }
    
    .main-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 25px;
        margin: 30px 0;
    }
    
    @media (max-width: 768px) {
        .stat-card {
        background: var(--white); /* Hindari gradien di mobile */
        border: 2px solid var(--gold); /* Tambahkan border gold */
        }
    }
    
    .gold-shadow {
    box-shadow: 0 4px 15px rgba(212, 175, 55, 0.2);
    }

    /* CARDS */
    .stat-card {
        background: linear-gradient(135deg, var(--white), var(--light-gray));
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        color: var(--dark-gray);
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        border: 1px solid rgba(26, 75, 140, 0.1);
    }
    
    .stat-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: var(--gold);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        border-color: rgba(212, 175, 55, 0.3);
    }
    
    .stat-card.blue-theme::before {
        background: var(--primary-blue);
    }
    
    .stat-card.gold-theme {
    background: linear-gradient(135deg, #fff9e6, var(--light-gold));
    border: 1px solid rgba(212, 175, 55, 0.3);
    }

    .stat-card.gold-theme h1 {
    color: var(--dark-gold);
    }

    .stat-card.gold-theme h3 {
    color: var(--dark-gold);
    }
    
    .stat-card.green-theme::before {
        background: var(--success);
    }
    
    .stat-card.purple-theme::before {
        background: #6a1b9a;
    }
    
    .stat-card h3 {
        margin: 0;
        font-size: 1rem;
        font-weight: 600;
        color: var(--primary-blue);
        margin-bottom: 10px;
    }
    
    .stat-card h1 {
        margin: 0;
        font-size: 2.8rem;
        font-weight: 700;
        color: var(--dark-blue);
        letter-spacing: -0.5px;
    }
    
    .info-card {
        background: var(--white);
        border: 1px solid rgba(26, 75, 140, 0.1);
        border-radius: 12px;
        padding: 25px;
        margin-bottom: 25px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.05);
    }
    
    .info-card h3 {
        margin-top: 0;
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 2px solid var(--light-gold);
        color: var(--primary-blue);
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
    }
    
    /* TABLES IMPROVED */
    .table-container {
        overflow-x: auto;
        border-radius: 8px;
        background: var(--white);
        border: 1px solid rgba(26, 75, 140, 0.1);
        margin-top: 15px;
    }
    
    .data-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 600px;
    }
    
    .data-table th {
        background: linear-gradient(to right, var(--primary-blue), var(--secondary-blue));
        padding: 16px 20px;
        text-align: left;
        font-weight: 600;
        color: var(--white);
        border: none;
    }
    
    .data-table td {
        padding: 14px 20px;
        border-bottom: 1px solid rgba(26, 75, 140, 0.1);
        color: var(--dark-gray);
    }
    
    .data-table tr:nth-child(even) {
    background: rgba(244, 232, 193, 0.2); /* Light gold background */
}
    
    .data-table tr:hover {
    background: rgba(232, 242, 255, 0.5); /* Light blue + gold mix */
}
    
    /* QUICK ACTIONS */
    .quick-actions {
        display: flex;
        gap: 15px;
        margin: 25px 0;
        flex-wrap: wrap;
    }
    
    .action-btn {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
        color: var(--white);
        border: none;
        padding: 12px 24px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
        cursor: pointer;
        text-decoration: none;
        font-size: 0.95rem;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 4px 10px rgba(26, 75, 140, 0.2);
    }
    
    .action-btn:hover {
        background: linear-gradient(135deg, var(--secondary-blue), var(--primary-blue));
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(26, 75, 140, 0.3);
    }
    
    .action-btn.gold {
        background: linear-gradient(135deg, var(--gold), var(--dark-gold));
    }
    
    .action-btn.gold:hover {
        background: linear-gradient(135deg, var(--dark-gold), var(--gold));
    }
    
    /* EMPTY STATES */
    .empty-state {
        text-align: center;
        padding: 40px 20px;
        color: #666;
        font-style: italic;
    }
    
    /* BADGES */
    .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        background: rgba(26, 75, 140, 0.1);
        color: var(--primary-blue);
    }
    
    .badge-gold {
        background: rgba(212, 175, 55, 0.2);
        color: var(--dark-gold);
    }
    
    .badge-success { 
        background: rgba(46, 125, 50, 0.1); 
        color: var(--success); 
    }
    
    .badge-warning { 
        background: rgba(255, 143, 0, 0.1); 
        color: var(--warning); 
    }
    
    .badge-danger { 
        background: rgba(198, 40, 40, 0.1); 
        color: var(--danger); 
    }
    
    /* CHART CONTAINER */
    .chart-container {
        background: var(--white);
        border-radius: 12px;
        padding: 25px;
        border: 1px solid rgba(26, 75, 140, 0.1);
        box-shadow: 0 3px 10px rgba(0,0,0,0.05);
        margin: 20px 0;
    }
    
    .chart-container canvas {
        max-height: 300px !important;
    }
    
    /* ICON STYLING */
    .gold-icon {
        color: var(--gold);
        font-size: 1.2em;
    }
    
    .blue-icon {
        color: var(--primary-blue);
        font-size: 1.2em;
    }
    
    /* PROGRESS BARS */
    .progress-bar {
        width: 100%;
        height: 8px;
        background: rgba(26, 75, 140, 0.1);
        border-radius: 4px;
        overflow: hidden;
        margin-top: 5px;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(to right, var(--gold), var(--dark-gold));
        border-radius: 4px;
    }
    
    /* DASHBOARD HEADER */
    .dashboard-header {
        background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
        color: var(--white);
        padding: 30px;
        border-radius: 12px;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
        border: 1px solid rgba(212, 175, 55, 0.3);
    }
    
    .dashboard-header::after {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 200px;
        height: 200px;
        background: linear-gradient(45deg, transparent, rgba(212, 175, 55, 0.1));
        border-radius: 50%;
        transform: translate(100px, -100px);
    }
    
    .dashboard-header h1 {
        margin: 0;
        font-size: 2.2rem;
        font-weight: 700;
        color: var(--white);
    }
    
    .dashboard-header p {
        margin: 10px 0 0;
        opacity: 0.9;
        max-width: 600px;
        color: var(--light-gold);
    }
    
    /* SOURCE CARDS */
    .source-card {
        text-align: center;
        padding: 20px;
        background: var(--white);
        border-radius: 10px;
        border: 2px solid rgba(26, 75, 140, 0.1);
        transition: all 0.3s ease;
    }
    
    .source-card:hover {
        border-color: var(--gold);
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .source-card .icon {
        font-size: 2.5rem;
        margin-bottom: 15px;
        color: var(--primary-blue);
    }
    
    .source-card .count {
        font-size: 2rem;
        font-weight: 700;
        color: var(--dark-blue);
        margin: 10px 0;
    }
    
    .source-card .label {
        color: #666;
        font-size: 0.9rem;
    }
    
    /* WELCOME MESSAGE */
    .welcome-message {
        background: linear-gradient(135deg, rgba(26, 75, 140, 0.05), rgba(212, 175, 55, 0.05));
        border-left: 4px solid var(--gold);
        padding: 20px;
        border-radius: 8px;
        margin: 20px 0;
    }
    
    .welcome-message h3 {
        color: var(--primary-blue);
        margin-top: 0;
    }
    
    /* NOTIFICATION BELL */
    .notification-badge {
        position: relative;
        display: inline-block;
    }
    
    .notification-badge::after {
        content: '';
        position: absolute;
        top: -5px;
        right: -5px;
        width: 12px;
        height: 12px;
        background: var(--danger);
        border-radius: 50%;
        border: 2px solid var(--white);
    }
    
    /* ANIMATIONS */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .fade-in {
        animation: fadeIn 0.5s ease-out;
    }
    
    /* FILTERS */
    .filter-group {
        display: flex;
        gap: 10px;
        margin: 20px 0;
        flex-wrap: wrap;
    }
    
    .filter-btn {
        padding: 8px 16px;
        background: var(--white);
        border: 1px solid rgba(26, 75, 140, 0.2);
        border-radius: 6px;
        color: var(--primary-blue);
        cursor: pointer;
        transition: all 0.3s ease;
        font-size: 0.9rem;
    }
    
    .filter-btn:hover, .filter-btn.active {
        background: var(--primary-blue);
        color: var(--white);
        border-color: var(--primary-blue);
    }
    
    /* ALERTS */
    .alert {
        padding: 15px 20px;
        border-radius: 8px;
        margin: 15px 0;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .alert-warning {
        background: rgba(255, 193, 7, 0.1);
        border-left: 4px solid #ffc107;
        color: #856404;
    }
    
    .alert-info {
        background: rgba(23, 162, 184, 0.1);
        border-left: 4px solid #17a2b8;
        color: #0c5460;
    }
    
    /* LOADING */
    .loading {
        text-align: center;
        padding: 40px;
        color: #666;
    }
    
    .loading-spinner {
        display: inline-block;
        width: 40px;
        height: 40px;
        border: 3px solid rgba(26, 75, 140, 0.1);
        border-radius: 50%;
        border-top-color: var(--gold);
        animation: spin 1s ease-in-out infinite;
        margin-bottom: 15px;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
</style>

<!-- DASHBOARD HEADER -->
<div class="dashboard-header">
    <h1><span style="color: var(--gold);">📊</span> Dashboard Admin SIPERAK</h1>
    <p style="color: var(--light-gold);">Sistem Informasi Perpustakaan R.A. Kartini - Selamat datang, <?= session()->get('nama') ?? 'Administrator' ?>!</p>
    
    <div class="quick-actions">
        <a href="<?= base_url('/buku/tambah') ?>" class="action-btn" style="background: linear-gradient(135deg, var(--gold), var(--dark-gold));">
            <span style="color: var(--navy-blue);">➕</span> <strong>Tambah Buku Baru</strong>
        </a>
        <!-- ... tombol lainnya ... -->
    </div>
</div>

<!-- WELCOME & ALERTS -->
<?php if($peminjamanTerlambat > 0): ?>
<div class="alert alert-warning fade-in">
    <span style="font-size: 1.5rem;">⚠️</span>
    <div>
        <strong>Perhatian!</strong> Terdapat <strong><?= $peminjamanTerlambat ?></strong> peminjaman yang terlambat.
        <a href="<?= base_url('/peminjaman/terlambat') ?>" style="color: inherit; text-decoration: underline; margin-left: 10px;">Lihat Detail</a>
    </div>
</div>
<?php endif; ?>

<!-- STATISTIK UTAMA -->
<h2 style="color: var(--primary-blue); margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
    <span>📈</span> Statistik Utama
</h2>

<div class="dashboard-grid">
    <div class="stat-card blue-theme fade-in" style="--order: 1;">
        <h3>Total Buku</h3>
        <h1><?= number_format($totalBuku) ?></h1>
        <div style="margin-top: 15px; font-size: 0.9rem; color: #666;">
            <span style="color: var(--primary-blue); font-weight: 600;">BOS: <?= $totalBukuBOS ?></span> | 
            <span style="color: var(--gold); font-weight: 600;">Perpustakaan: <?= $totalBukuPerpustakaan ?></span>
        </div>
    </div>
    
    <div class="stat-card green-theme fade-in" style="--order: 2;">
        <h3>Peminjaman Hari Ini</h3>
        <h1><?= $peminjamanHariIni ?></h1>
        <div style="margin-top: 15px;">
            <span class="status-badge badge-success">Aktif</span>
        </div>
    </div>
    
    <div class="stat-card gold-theme fade-in" style="--order: 3;">
        <h3>Peminjaman Aktif</h3>
        <h1><?= $peminjamanAktif ?? 0 ?></h1>
        <div style="margin-top: 15px;">
            <?php if(($peminjamanTerlambat ?? 0) > 0): ?>
                <span class="status-badge badge-danger"><?= $peminjamanTerlambat ?> terlambat</span>
            <?php else: ?>
                <span class="status-badge badge-success">Semua tepat waktu</span>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="stat-card purple-theme fade-in" style="--order: 4;">
        <h3>Ketersediaan Buku</h3>
        <h1><?= number_format(($totalBuku - ($peminjamanAktif ?? 0))) ?></h1>
        <div style="margin-top: 15px; font-size: 0.9rem; color: #666;">
            Tersedia untuk dipinjam
        </div>
    </div>
</div>

<!-- FILTER PERIODE -->
<div class="filter-group">
    <button class="filter-btn active" style="background: var(--primary-blue); color: white; border: 2px solid var(--gold);">7 Hari</button>
    <button class="filter-btn" style="border: 2px solid var(--primary-blue);">30 Hari</button>
    <button class="filter-btn" style="border: 2px solid var(--primary-blue);">12 Bulan</button>
</div>

<!-- MAIN CONTENT GRID -->
<div class="main-grid">
    <!-- LEFT COLUMN -->
    <div>
        <!-- GRAFIK PEMINJAMAN -->
        <div class="info-card">
            <h3><span class="gold-icon">📈</span> Tren Peminjaman</h3>
            <div class="chart-container">
                <canvas id="grafikPeminjaman" height="250"></canvas>
            </div>
            <div style="margin-top: 15px; font-size: 0.9rem; color: #666; text-align: center;">
                Total peminjaman bulan ini: <strong style="color: var(--primary-blue);"><?= array_sum($grafikData) ?></strong> buku
            </div>
        </div>
        
        <!-- BUKU TERBARU -->
        <div class="info-card">
            <h3><span class="blue-icon">📚</span> Buku Terbaru</h3>
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Cover</th>
                            <th>Nama Buku</th>
                            <th>Kategori</th>
                            <th>Tahun</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($terbaru)): ?>
                            <?php foreach($terbaru as $b): ?>
                            <tr>
                                <td>
                                    <?php if(!empty($b['cover']) && file_exists('uploads/' . $b['cover'])): ?>
                                        <img src="<?= base_url('uploads/' . $b['cover']) ?>" 
                                             width="45" 
                                             style="border-radius:6px;border:2px solid var(--light-gold);"
                                             alt="Cover <?= esc($b['nama_buku']) ?>">
                                    <?php else: ?>
                                        <div style="width:45px;height:60px;background:linear-gradient(135deg, var(--light-blue), #d1e4ff);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:0.8rem;color:var(--primary-blue);border:2px solid var(--light-gold);">
                                            📚
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong style="color: var(--dark-blue);"><?= esc($b['nama_buku']) ?></strong>
                                    <?php if(!empty($b['penulis'])): ?>
                                        <div style="font-size:0.85rem;color:#666;"><?= esc($b['penulis']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status-badge"><?= esc($b['kategori'] ?? '-') ?></span>
                                </td>
                                <td><?= $b['tahun_terbit'] ?? ($b['tahun'] ?? '-') ?></td>
                            </tr>
                            <?php endforeach ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="empty-state">Belum ada buku terbaru</td>
                            </tr>
                        <?php endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- RIGHT COLUMN -->
    <div>
        <!-- DISTRIBUSI KATEGORI -->
        <div class="info-card">
            <h3><span class="gold-icon">📊</span> Distribusi Kategori</h3>
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Kategori</th>
                            <th>Jumlah</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($kategori)): ?>
                            <?php $total = $totalBuku > 0 ? $totalBuku : 1; ?>
                            <?php foreach($kategori as $k): ?>
                            <?php $percentage = round(($k['jumlah'] / $total) * 100, 1); ?>
                            <tr>
                                <td><?= esc($k['kategori']) ?></td>
                                <td><strong style="color: var(--primary-blue);"><?= $k['jumlah'] ?></strong></td>
                                <td>
                                    <div style="display:flex;align-items:center;gap:10px;">
                                        <div class="progress-bar">
                                            <div class="progress-fill" style="width:<?= $percentage ?>%;"></div>
                                        </div>
                                        <span style="color: var(--dark-blue);font-weight:600;"><?= $percentage ?>%</span>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="empty-state">Belum ada data kategori</td>
                            </tr>
                        <?php endif ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- AKTIVITAS TERBARU -->
        <div class="info-card">
            <h3><span class="blue-icon">🕒</span> Aktivitas Terbaru</h3>
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Buku</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($peminjamanTerbaru)): ?>
                            <?php foreach(array_slice($peminjamanTerbaru, 0, 5) as $p): ?>
                            <?php 
                                $status_lower = strtolower($p['status']);
                                if ($status_lower === 'diproses') {
                                    $statusClass = 'badge-warning';
                                } elseif ($status_lower === 'disetujui') {
                                    $statusClass = 'badge-gold';
                                } elseif ($status_lower === 'ditolak') {
                                    $statusClass = 'badge-danger';
                                } elseif ($status_lower === 'kembali' || $status_lower === 'dikembalikan') {
                                    $statusClass = 'badge-success';
                                } elseif ($status_lower === 'terlambat') {
                                    $statusClass = 'badge-danger';
                                } else {
                                    $statusClass = 'badge-secondary';
                                }
                            ?>
                            <tr>
                                <td>
                                    <div><strong style="color: var(--dark-blue);"><?= esc($p['nama']) ?></strong></div>
                                    <div style="font-size:0.8rem;color:#666;"><?= $p['nis'] ?? 'N/A' ?></div>
                                </td>
                                <td style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <?= esc($p['nama_buku']) ?>
                                </td>
                                <td>
                                    <span class="status-badge <?= $statusClass ?>">
                                        <?= $p['status'] ?? 'Diproses' ?>
                                    </span>
                                    <?php if(!empty($p['tanggal_pinjam'])): ?>
                                        <div style="font-size:0.8rem;color:#666;">
                                            <?= date('d/m', strtotime($p['tanggal_pinjam'])) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="empty-state">Belum ada aktivitas peminjaman</td>
                            </tr>
                        <?php endif ?>
                    </tbody>
                </table>
            </div>
            <?php if(!empty($peminjamanTerbaru)): ?>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="<?= base_url('/peminjaman') ?>" style="color: var(--primary-blue); text-decoration: none; font-size: 0.9rem;">
                        Lihat semua aktivitas →
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- SUMBER BUKU -->
        <div class="info-card">
            <h3><span class="gold-icon">📦</span> Sumber Buku</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 15px;">
                <div class="source-card">
                    <div class="icon">🏫</div>
                    <div class="count" style="color: var(--primary-blue);"><?= $totalBukuBOS ?></div>
                    <div class="label">Buku BOS</div>
                    <div style="margin-top: 10px; font-size: 0.8rem; color: #666;">
                        <?php if($totalBuku > 0): ?>
                            <?= round(($totalBukuBOS / $totalBuku) * 100, 1) ?>% dari total
                        <?php endif; ?>
                    </div>
                </div>
                <div class="source-card">
                    <div class="icon">📚</div>
                    <div class="count" style="color: var(--gold);"><?= $totalBukuPerpustakaan ?></div>
                    <div class="label">Perpustakaan</div>
                    <div style="margin-top: 10px; font-size: 0.8rem; color: #666;">
                        <?php if($totalBuku > 0): ?>
                            <?= round(($totalBukuPerpustakaan / $totalBuku) * 100, 1) ?>% dari total
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- LOADING INDICATOR -->
<div id="loadingIndicator" class="loading" style="display: none;">
    <div class="loading-spinner"></div>
    <div>Memperbarui data...</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Global chart instance
let peminjamanChart = null;

// Initialize chart
function initChart(labels, data) {
    const ctx = document.getElementById('grafikPeminjaman');
    
    if (peminjamanChart) {
        peminjamanChart.destroy();
    }
    
    peminjamanChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Jumlah Peminjaman',
                data: data,
                borderColor: '#d4af37', // GOLD
                backgroundColor: 'rgba(212, 175, 55, 0.15)',
                borderWidth: 3,
                fill: true,
                tension: 0.3,
                pointBackgroundColor: '#1a4b8c', // BLUE
                pointBorderColor: '#d4af37',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: '#333333',
                        font: {
                            weight: '600',
                            size: 12
                        }
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(26, 75, 140, 0.9)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: '#d4af37',
                    borderWidth: 1,
                    padding: 12,
                    cornerRadius: 6
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(26, 75, 140, 0.1)'
                    },
                    ticks: {
                        color: '#666666',
                        font: {
                            size: 11
                        }
                    },
                    title: {
                        display: true,
                        text: 'Jumlah Peminjaman',
                        color: '#666666',
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(26, 75, 140, 0.1)'
                    },
                    ticks: {
                        color: '#666666',
                        font: {
                            size: 11
                        }
                    },
                    title: {
                        display: true,
                        text: 'Periode',
                        color: '#666666',
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    }
                }
            }
        }
    });
}

// Update chart data
function updateChart(periode) {
    // Update active filter button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Show loading
    document.getElementById('loadingIndicator').style.display = 'block';
    
    // Fetch new chart data
    fetch(`<?= base_url('dashboard/chart-data/') ?>${periode}`)
        .then(response => response.json())
        .then(data => {
            initChart(data.labels, data.data);
            document.getElementById('loadingIndicator').style.display = 'none';
        })
        .catch(error => {
            console.error('Error fetching chart data:', error);
            document.getElementById('loadingIndicator').style.display = 'none';
        });
}

// Initialize with default data
document.addEventListener('DOMContentLoaded', function() {
    const labels = <?= json_encode($grafikLabel) ?>;
    const data = <?= json_encode($grafikData) ?>;
    initChart(labels, data);
    
    // Auto-refresh stats every 30 seconds
    setInterval(() => {
        fetch('<?= base_url("dashboard/refresh-stats") ?>')
            .then(response => response.json())
            .then(stats => {
                if (stats.success) {
                    // Update statistic cards
                    const cards = document.querySelectorAll('.stat-card h1');
                    if (cards.length >= 2) {
                        cards[1].textContent = stats.peminjamanHariIni;
                        cards[2].textContent = stats.peminjamanAktif;
                        
                        // Update availability card
                        const totalBuku = <?= $totalBuku ?>;
                        cards[3].textContent = (totalBuku - stats.peminjamanAktif).toLocaleString();
                    }
                }
            })
            .catch(error => console.error('Error refreshing stats:', error));
    }, 30000);
    
    // Add hover effect to cards
    const cards = document.querySelectorAll('.stat-card');
    cards.forEach((card, index) => {
        card.style.setProperty('--order', index);
    });
});
</script>

<?= $this->endSection() ?>

<!-- Tambahkan di akhir admin_view.php -->
<div style="margin-top: 40px; padding: 20px; text-align: center; background: linear-gradient(90deg, var(--primary-blue), var(--secondary-blue)); color: white; border-radius: 12px; border-top: 3px solid var(--gold);">
    <p style="margin: 0; color: var(--light-gold);">
        SIPERAK © 2024 - SMA Negeri 1 Tanjungpinang 
        <span style="color: white; font-weight: bold; margin: 0 10px;">|</span>
        <i class="fas fa-book" style="color: var(--gold);"></i> Total Buku: <?= $totalBuku ?>
        <span style="color: white; font-weight: bold; margin: 0 10px;">|</span>
        <i class="fas fa-users" style="color: var(--gold);"></i> Sistem Informasi Perpustakaan
    </p>
</div>

<!-- Tambahkan di admin_view.php -->
<div class="sr-only" role="status" id="liveRegion" aria-live="polite"></div>

<script>
// Announce changes to screen readers
function announceToScreenReader(message) {
    const liveRegion = document.getElementById('liveRegion');
    liveRegion.textContent = message;
    setTimeout(() => {
        liveRegion.textContent = '';
    }, 1000);
}
</script>
