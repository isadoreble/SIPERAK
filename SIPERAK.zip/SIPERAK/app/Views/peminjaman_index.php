<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Daftar Peminjaman</title>
<style>
body{font-family:Segoe UI, sans-serif;background:#f4f6fb;margin:0;padding:20px}
.container{max-width:1200px;margin:0 auto}
.table{width:100%;border-collapse:collapse;background:#fff;box-shadow:0 6px 18px rgba(0,0,0,0.06)}
.table th, .table td{padding:10px;border-bottom:1px solid #eee;text-align:left}
.table th{background:#1e3c72;color:#fff}
.badge{padding:6px 10px;border-radius:6px;color:#fff;font-weight:bold}
.bad-diproses{background:#f39c12}
.bad-disetujui{background:#27ae60}
.bad-ditolak{background:#c0392b}
.bad-terlambat{background:#e74c3c}
.actions a{margin-right:8px;text-decoration:none;color:#1e3c72}
.alert{padding:8px 12px;margin-bottom:15px;border-radius:6px}
.alert-success{background:#e6ffed;border:1px solid #b7f0c3;color:#067a2b}
.alert-error{background:#fff0f0;border:1px solid #f1c0c0;color:#a33}
</style>
</head>
<body>
<div class="container">
<h2>Daftar Peminjaman</h2>
<p><a href="<?= base_url('/admin') ?>">◀ Kembali ke Dashboard</a></p>

<?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-error"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<table class="table">
<thead>
<tr>
<th>#</th>
<th>Nama Siswa</th>
<th>NIS</th>
<th>Buku</th>
<th>Tgl Pinjam</th>
<th>Tgl Kembali</th>
<th>Status</th>
<th>Aksi</th>
</tr>
</thead>
<tbody>
<?php if (!empty($peminjaman)) : ?>
    <?php foreach ($peminjaman as $i => $p) : ?>
    <tr>
        <td><?= $i+1 ?></td>
        <td><?= esc($p['nama'] ?? $p['users.nama'] ?? '-') ?></td>
        <td><?= esc($p['nis']) ?></td>
        <td><?= esc($p['nama_buku']) ?></td>
        <td><?= esc($p['tanggal_pinjam']) ?></td>
        <td><?= esc($p['tanggal_kembali'] ?? '-') ?></td>
        <td>
            <?php $st = strtolower($p['status']); ?>
            <span class="badge <?= ($st=='diproses'?'bad-diproses':($st=='disetujui'?'bad-disetujui':($st=='ditolak'?'bad-ditolak':'bad-terlambat'))) ?>">
                <?= esc($p['status']) ?>
            </span>
        </td>
        <td class="actions">
            <?php if (!empty($p['id']) && $p['status'] == 'Diproses') : ?>
                <a href="<?= base_url('/peminjaman/setujui/'.$p['id']) ?>" onclick="return confirm('Setujui peminjaman ini?')">✅ Setujui</a>
                <a href="<?= base_url('/peminjaman/tolak/'.$p['id']) ?>" onclick="return confirm('Tolak peminjaman ini?')">❌ Tolak</a>
            <?php endif; ?>

            <?php if (!empty($p['id']) && ($p['status'] == 'Disetujui' || strtolower($p['status']) == 'dipinjam')) : ?>
                <a href="<?= base_url('/peminjaman/kembali/'.$p['id']) ?>" onclick="return confirm('Tandai buku ini telah dikembalikan?')">🔄 Kembalikan</a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr><td colspan="8">Belum ada peminjaman.</td></tr>
<?php endif; ?>
</tbody>
</table>

</div>
</body>
</html>