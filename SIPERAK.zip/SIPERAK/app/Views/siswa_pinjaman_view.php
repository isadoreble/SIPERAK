<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pinjaman Saya</title>

<style>
body {
    font-family: Segoe UI, sans-serif;
    background: #f4f6fb;
    margin: 0;
    padding: 20px;
}

.container{max-width:1200px;margin:0 auto}

h2 {
    color: #1e3c72;
}

.back-link{margin-bottom:15px}
.back-link a{color:#1e3c72;text-decoration:none}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    margin-top: 20px;
    box-shadow: 0 5px 12px rgba(0,0,0,0.08);
}

th, td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    text-align: left;
}

th {
    background: #1e3c72;
    color: white;
}

.status {
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: bold;
    color: white;
    display: inline-block;
}

.diproses {background: #f39c12;}
.disetujui {background: #27ae60;}
.terlambat {background: #e74c3c;}
.kembali {background: #16a085;}
.ditolak {background: #c0392b;}
</style>
</head>

<body>

<div class="container">
<div class="back-link"><a href="<?= base_url('/siswa') ?>">◀ Kembali ke Dashboard</a></div>

<h2>📚 Riwayat Pinjaman Saya</h2>

<table>
<thead>
<tr>
    <th>#</th>
    <th>Buku</th>
    <th>Tanggal Pinjam</th>
    <th>Jatuh Tempo</th>
    <th>Status</th>
</tr>
</thead>
<tbody>

<?php if (!empty($pinjaman)) : ?>
<?php foreach ($pinjaman as $i => $p) : ?>
<?php 
    $status_lower = strtolower($p['status']);
    $statusClass = 'diproses';
    if ($status_lower == 'disetujui') $statusClass = 'disetujui';
    elseif ($status_lower == 'kembali') $statusClass = 'kembali';
    elseif ($status_lower == 'ditolak') $statusClass = 'ditolak';
    elseif ($status_lower == 'terlambat') $statusClass = 'terlambat';
    elseif ($p['tanggal_kembali'] && $p['tanggal_kembali'] < date('Y-m-d') && $status_lower == 'disetujui') $statusClass = 'terlambat';
?>
<tr>
    <td><?= $i+1 ?></td>
    <td><?= esc($p['nama_buku'] ?? $p['buku_id']) ?></td>
    <td><?= esc($p['tanggal_pinjam']) ?></td>
    <td><?= esc($p['tanggal_kembali'] ?? 'Menunggu Persetujuan') ?></td>
    <td>
        <span class="status <?= $statusClass ?>">
            <?= esc($p['status']) ?>
        </span>
    </td>
</tr>
<?php endforeach; ?>
<?php else : ?>
<tr>
    <td colspan="5" style="text-align:center">Belum ada pinjaman</td>
</tr>
<?php endif; ?>

</tbody>
</table>

</div>

</body>
</html>
