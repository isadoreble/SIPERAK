<h2>👑 Dashboard Admin</h2>
<p>Selamat datang, <?= session()->get('nama') ?></p>
<a href="/logout">Logout</a>
