<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>SIPERAK | Sistem Perpustakaan R.A Kartini</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f2f6fc;
        }

        header {
            background: #0d47a1;
            color: white;
            padding: 15px 30px;
            display: flex;
            align-items: center;
        }

        header img {
            height: 60px;
            margin-right: 15px;
        }

        nav {
            background: #1565c0;
            padding: 10px 30px;
        }

        nav a {
            color: white;
            margin-right: 20px;
            text-decoration: none;
            font-weight: bold;
        }

        nav a:hover {
            text-decoration: underline;
        }

        .container {
            padding: 30px;
        }

        .card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
        }

        .card h2 {
            margin-top: 0;
            color: #0d47a1;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
        }

        th {
            background: #e3f2fd;
        }

        input, button {
            padding: 8px;
            margin-top: 5px;
            width: 100%;
        }

        button {
            background: #0d47a1;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #1565c0;
        }

        footer {
            background: #0d47a1;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 40px;
        }
    </style>
</head>
<body>

<header>
    <img src="/Logo.jpeg" alt="Logo SMA">
    <div>
        <h1>SIPERAK</h1>
        <small>Sistem Perpustakaan R.A Kartini<br>SMA Negeri 1 Tanjungpinang</small>
    </div>
</header>

<nav>
    <a href="#">Dashboard</a>
    <a href="#">Data Buku</a>
    <a href="#">Data Anggota</a>
    <a href="#">Peminjaman</a>
</nav>

<div class="container">

    <div class="card">
        <h2>Tambah Buku</h2>
        <form>
            <label>Judul Buku</label>
            <input type="text">

            <label>Penulis</label>
            <input type="text">

            <label>Tahun</label>
            <input type="text">

            <button type="submit">Simpan Buku</button>
        </form>
    </div>

    <div class="card">
        <h2>Data Buku</h2>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Tahun</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Contoh Buku</td>
                    <td>Admin</td>
                    <td>2025</td>
                </tr>
            </tbody>
        </table>
    </div>

</div>

<footer>
    © 2026 SIPERAK - SMA Negeri 1 Tanjungpinang
</footer>

</body>
</html>
