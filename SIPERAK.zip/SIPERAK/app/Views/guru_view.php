<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Guru - SIPERAK</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- CSS KHUSUS DASHBOARD GURU -->
    <link rel="stylesheet" href="<?= base_url('assets/css/Dashboard_guru.css') ?>">
    
    <!-- ICONS (FontAwesome) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* Additional inline styles for icons */
        .stat-box i {
            font-size: 24px;
            margin-bottom: 15px;
            color: var(--accent);
        }
        
        .card-info i {
            margin-right: 8px;
            color: var(--accent);
        }
    </style>
</head>
<body>

<div class="navbar">
    <div class="nav-left">
        <img src="<?= base_url('assets/img/logo.png') ?>" alt="Logo SIPERAK">
        <h2>Guru Panel</h2>
    </div>
    <div class="nav-right">
        <a href="#"><i class="fas fa-book"></i> Data Buku</a>
        <a href="#"><i class="fas fa-exchange-alt"></i> Peminjaman</a>
        <a href="#"><i class="fas fa-users"></i> Siswa</a>
        <a href="<?= base_url('/logout') ?>"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<div class="hero">
    <div class="hero-box">
        <h1>Dashboard Guru <span>SIPERAK</span></h1>
        <p>Kelola peminjaman dan data siswa dengan sistem perpustakaan digital modern. Akses cepat ke semua fitur manajemen perpustakaan sekolah.</p>
        <button class="btn"><i class="fas fa-play-circle"></i> Mulai Mengelola</button>
    </div>
</div>

<div class="stats">
    <div class="stat-box">
        <i class="fas fa-book-open"></i>
        <h3>128</h3>
        <p>Buku Aktif</p>
    </div>
    <div class="stat-box">
        <i class="fas fa-hand-holding"></i>
        <h3>45</h3>
        <p>Dipinjam</p>
    </div>
    <div class="stat-box">
        <i class="fas fa-user-graduate"></i>
        <h3>320</h3>
        <p>Siswa Terdaftar</p>
    </div>
</div>

<div class="section">
    <h2><i class="fas fa-th-large"></i> Menu Guru</h2>
    <div class="row">
        <div class="card">
            <img src="<?= base_url('assets/img/books1.jpg') ?>" alt="Kelola Buku">
            <div class="card-info">
                <h3><i class="fas fa-book"></i> Kelola Buku</h3>
                <p>Tambah, edit, atau hapus koleksi buku perpustakaan. Kelola kategori dan stok buku dengan mudah.</p>
                <button><i class="fas fa-external-link-alt"></i> Buka</button>
            </div>
        </div>

        <div class="card">
            <img src="<?= base_url('assets/img/books2.jpg') ?>" alt="Peminjaman">
            <div class="card-info">
                <h3><i class="fas fa-exchange-alt"></i> Peminjaman</h3>
                <p>Kelola proses peminjaman dan pengembalian buku. Pantau status dan tenggat waktu pengembalian.</p>
                <button><i class="fas fa-external-link-alt"></i> Buka</button>
            </div>
        </div>

        <div class="card">
            <img src="<?= base_url('assets/img/books3.jpg') ?>" alt="Data Siswa">
            <div class="card-info">
                <h3><i class="fas fa-users"></i> Data Siswa</h3>
                <p>Kelola data siswa dan riwayat peminjaman. Lihat statistik dan aktivitas peminjaman per siswa.</p>
                <button><i class="fas fa-external-link-alt"></i> Buka</button>
            </div>
        </div>
    </div>
</div>

<div class="footer">
    <p><span>SIPERAK</span> — Guru Panel SMA Negeri 1 Tanjungpinang</p>
</div>

<script>
    // Interaktivitas tambahan
    document.addEventListener('DOMContentLoaded', function() {
        // Efek klik pada tombol
        const buttons = document.querySelectorAll('.btn, .card-info button');
        buttons.forEach(button => {
            button.addEventListener('click', function(e) {
                // Efek ripple
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size/2;
                const y = e.clientY - rect.top - size/2;
                
                ripple.style.cssText = `
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.7);
                    transform: scale(0);
                    animation: ripple 0.6s linear;
                    width: ${size}px;
                    height: ${size}px;
                    top: ${y}px;
                    left: ${x}px;
                    pointer-events: none;
                `;
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });
        
        // Animasi stat counter (opsional)
        const statNumbers = document.querySelectorAll('.stat-box h3');
        statNumbers.forEach(stat => {
            const target = parseInt(stat.textContent);
            let current = 0;
            const increment = target / 50;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    stat.textContent = target;
                    clearInterval(timer);
                } else {
                    stat.textContent = Math.floor(current);
                }
            }, 30);
        });
    });
    
    // Tambahkan style untuk efek ripple
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        .btn, .card-info button {
            position: relative;
            overflow: hidden;
        }
    `;
    document.head.appendChild(style);
</script>

</body>
</html>