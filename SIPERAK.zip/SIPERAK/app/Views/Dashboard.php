<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>SIPERAK - SMA Negeri 1 Tanjungpinang</title>

    <!-- CSS FOOTER -->
    <link rel="stylesheet" href="<?= base_url('assets/css/Footer.css') ?>">

    <style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background: #f0f6ff;
    }

    /* NAVBAR */
    .navbar {
        background: #0d47a1;
        display: flex;
        align-items: center;
        padding: 10px 30px;
        color: white;
    }

    .navbar img {
        height: 45px;
        margin-right: 15px;
    }

    .navbar h2 {
        flex: 1;
    }

    .navbar a {
        color: white;
        text-decoration: none;
        margin-left: 20px;
        font-weight: bold;
    }

    /* BANNER */
    .banner {
        background: linear-gradient(to right, rgba(13,71,161,0.9), rgba(13,71,161,0.4)),
                    url('https://images.unsplash.com/1544717305-2782549b5136');
        background-size: cover;
        padding: 80px;
        color: white;
    }

    .banner h1 {
        font-size: 45px;
    }

    .banner button {
        padding: 10px 25px;
        border: none;
        background: white;
        color: #0d47a1;
        font-weight: bold;
        cursor: pointer;
        border-radius: 5px;
    }

    /* ROW */
    .row {
        padding: 20px;
    }

    .row h3 {
        color: #0d47a1;
    }

    /* SLIDER */
    .slider {
        display: flex;
        overflow-x: auto;
    }

    .card {
        min-width: 160px;
        background: white;
        margin-right: 15px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        transition: 0.3s;
        cursor: pointer;
    }

    .card:hover {
        transform: scale(1.1);
    }

    .card img {
        width: 100%;
        height: 200px;
        border-radius: 10px 10px 0 0;
        object-fit: cover;
    }

    .card .info {
        padding: 10px;
    }

    .card button {
        width: 100%;
        padding: 5px;
        background: #0d47a1;
        color: white;
        border: none;
        border-radius: 5px;
    }
    </style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <img src="<?= base_url('assets/logo.png') ?>">
    <h2>SIPERAK - SMA Negeri 1 Tanjungpinang</h2>
    <a href="<?= base_url('dashboard') ?>">Dashboard</a>
    <a href="<?= site_url('siswa/pinjaman') ?>">Peminjaman</a>
    <a href="<?= site_url('profil') ?>">Profil</a>
    <a href="<?= base_url('logout') ?>">Logout</a>
</div>

<!-- BANNER -->
<div class="banner">
    <h1>Buku Unggulan Hari Ini</h1>
    <p>Jelajahi dunia lewat buku digital perpustakaan sekolah</p>
    <button>📖 Pinjam Sekarang</button>
</div>

<!-- RAK BUKU -->
<div class="row">
    <h3>📘 Buku Pelajaran</h3>
    <div class="slider">
        <div class="card">
            <img src="https://covers.openlibrary.org/b/id/10521258-L.jpg">
            <div class="info">
                <b>Matematika</b>
                <button>Pinjam</button>
            </div>
        </div>

        <div class="card">
            <img src="https://covers.openlibrary.org/b/id/10909258-L.jpg">
            <div class="info">
                <b>Fisika</b>
                <button>Pinjam</button>
            </div>
        </div>

        <div class="card">
            <img src="https://covers.openlibrary.org/b/id/11153258-L.jpg">
            <div class="info">
                <b>Kimia</b>
                <button>Pinjam</button>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <h3>📗 Novel & Cerita</h3>
    <div class="slider">
        <div class="card">
            <img src="<?= base_url('assets/img/Laskar Pelangi.jpg') ?>">
            <div class="info">
                <b>Laskar Pelangi</b>
                <button>Pinjam</button>
            </div>
        </div>

        <div class="card">
            <img src="<?= base_url('assets/img/Laut Bercerita.jpg') ?>">
            <div class="info">
                <b>Laut Bercerita</b>
                <button>Pinjam</button>
            </div>
        </div>
    </div>
</div>

<!-- FOOTER HARUS DI SINI -->
<?= $this->include('layout/footer') ?>

</body>
</html>
