<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>SIPERAK Admin</title>

    <link rel="stylesheet" href="<?= base_url('assets/css/dashboard.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/admin.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/Footer.css') ?>">

    <!-- ===== TAMBAHAN FIX OFFSIDE (WAJIB) ===== -->
    <style>
        html, body {
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
        }

        .main {
            max-width: 100%;
            box-sizing: border-box;
        }

        .library-footer {
            max-width: 100%;
            box-sizing: border-box;
        }

        /* TAMBAHAN MENU SECTION */
        .menu-section {
            margin-top: 10px;
            padding-left: 12px;
            font-size: 12px;
            opacity: .7;
            text-transform: uppercase;
        }
    </style>
</head>

<body>

<?php
    // ===== MENU AKTIF DINAMIS =====
    $uri = service('uri')->getSegment(1);
?>

<!-- SIDEBAR -->
<div class="sidebar collapsed">
    <div class="logo">
        <img src="<?= base_url('assets/img/Logo.jpeg') ?>">
        <span>SIPERAK</span>
    </div>

    <a href="<?= base_url('/admin') ?>" class="<?= ($uri == 'admin') ? 'active' : '' ?>">
        📊 Dashboard
    </a>

    <!-- ===== SECTION BUKU ===== -->
    <div class="menu-section">Manajemen Buku</div>

    <a href="<?= base_url('/buku') ?>" class="<?= ($uri == 'buku') ? 'active' : '' ?>">
        📚 Semua Buku
    </a>

    <!-- ===== BUKU BOS ===== -->
    <div class="menu-section">Buku BOS</div>

    <a href="<?= base_url('/buku-bos') ?>" class="<?= ($uri == 'buku-bos') ? 'active' : '' ?>">
        🏫 Data Buku BOS
    </a>

    <a href="<?= base_url('/buku-bos/tambah') ?>" class="<?= ($uri == 'tambah-buku-bos') ? 'active' : '' ?>">
        ➕ Tambah Buku BOS
    </a>

    <!-- ===== BUKU PERPUSTAKAAN ===== -->
    <div class="menu-section">Perpustakaan</div>

    <a href="<?= base_url('/buku-perpustakaan') ?>" class="<?= ($uri == 'buku-perpustakaan') ? 'active' : '' ?>">
        📖 Data Buku Perpustakaan
    </a>

    <a href="<?= base_url('/buku-perpustakaan/tambah') ?>" class="<?= ($uri == 'tambah-buku-perpustakaan') ? 'active' : '' ?>">
        ➕ Tambah Buku Perpustakaan
    </a>

    <div class="menu-section">Peminjaman</div>

    <a href="<?= base_url('/peminjaman') ?>" class="<?= ($uri == 'peminjaman') ? 'active' : '' ?>">
        📚 Daftar Peminjaman
    </a>

    <a href="<?= base_url('/logout') ?>">
        🚪 Logout
    </a>
</div>

<!-- MAIN CONTENT -->
<div class="main">

    <div class="header">
        <div style="display:flex;align-items:center;gap:15px;">
            <div class="toggle-btn" id="toggleBtn">☰</div>
            <h2>Dashboard Admin</h2>
        </div>
        <span>Sistem Perpustakaan R.A. Kartini</span>
    </div>

    <?= $this->renderSection('content') ?>

</div>

<!-- FOOTER -->
<footer class="library-footer">
    <div class="footer-container">

        <!-- Branding -->
        <div class="footer-brand">
            <img src="<?= base_url('assets/img/logo smansa.png') ?>" class="footer-logo">

            <h3>SIPERAK</h3>
            <span class="system-subtitle">
                Sistem Informasi Perpustakaan R.A. Kartini
            </span>

            <a href="https://www.sman1-tpi.sch.id/#" 
               class="school-name" 
               target="_blank" 
               rel="noopener">
               SMA Negeri 1 Tanjungpinang
            </a>

            <p class="brand-desc">
                SIPERAK merupakan sistem perpustakaan digital yang mendukung
                budaya literasi, pembelajaran mandiri, serta akses informasi
                yang inklusif bagi seluruh warga sekolah.
            </p>
        </div>

        <!-- Informasi Sekolah -->
        <div class="footer-info">
            <h4>Informasi Sekolah</h4>
            <ul>
                <li>
                    <a href="https://maps.app.goo.gl/zDsQd19hchCATHRF6" target="_blank">
                        <ion-icon name="location-outline"></ion-icon>
                        Jl. Dr. Sutomo, Tanjungpinang
                    </a>
                </li>
                <li>
                    <a href="https://maps.app.goo.gl/zDsQd19hchCATHRF6" target="_blank">
                        <ion-icon name="map-outline"></ion-icon>
                        Kepulauan Riau, 29100
                    </a>
                </li>
                <li>
                    <a href="tel:+62077121216">
                        <ion-icon name="call-outline"></ion-icon>
                        +62-0771-21216
                    </a>
                </li>
                <li>
                    <a href="mailto:info@sman1-tpi.sch.id">
                        <ion-icon name="mail-outline"></ion-icon>
                        info@sman1-tpi.sch.id
                    </a>
                </li>
            </ul>
        </div>

        <!-- Layanan -->
        <div class="footer-services">
            <h4>Layanan Perpustakaan</h4>
            <ul>
                <li>Katalog Buku Digital</li>
                <li>Pojok Literasi</li>
                <li>Referensi & Jurnal</li>
                <li>Ruang Baca Nyaman</li>
                <li>Literasi Informasi</li>
            </ul>
        </div>

        <!-- Media Sosial -->
        <div class="footer-social">
            <h4>Media Sosial</h4>
            <div class="social-icons">
                <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
                <a href="#"><ion-icon name="logo-twitter"></ion-icon></a>
                <a href="#"><ion-icon name="logo-google"></ion-icon></a>
                <a href="#"><ion-icon name="logo-youtube"></ion-icon></a>
                <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
            </div>
        </div>

    </div>

    <div class="footer-bottom">
        <p>© 2026 SIPERAK — Perpustakaan R.A. Kartini</p>
        <span class="footer-quote">
            Designed and developed by Silver Code Collective — SIPERAK Team
        </span>
    </div>
</footer>

<!-- TOGGLE SIDEBAR -->
<script>
document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("toggleBtn");
    const sidebar = document.querySelector(".sidebar");

    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("collapsed");
    });
});
</script>

<!-- IONICONS -->
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>


</body>
</html>
