<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Buku SIPERAK</title>

    <!-- CSS FIXED PATH -->
    <link rel="stylesheet" href="<?= base_url('/assets/css/dashboard.css') ?>">

    <style>
        /* =======================
           FIX NAVBAR + SIDEBAR
        ======================== */
        .navbar {
            position: fixed;
            top: 0;
            left: 240px; /* SAMA DENGAN WIDTH SIDEBAR */
            width: calc(100% - 240px);
            height: 64px;
            background: linear-gradient(135deg, #0f172a, #020617);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 32px;
            box-sizing: border-box;
            z-index: 1000;
        }

        .nav-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nav-left img {
            height: 40px;
            width: auto;
            object-fit: contain;
        }

        .nav-left h2 {
            color: #fff;
            font-size: 20px;
            margin: 0;
            font-weight: 700;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            margin-left: 24px;
            font-weight: 500;
        }

        .navbar a:hover {
            text-decoration: underline;
        }

        /* =======================
           RESET AREA FORM
        ======================== */
        body {
            box-sizing: border-box;
        }

        body .section {
            max-width: 820px !important;
            margin: 120px auto !important;
            padding: 48px 56px !important;
            background: rgba(255,255,255,0.07) !important;
            border-radius: 22px !important;
            backdrop-filter: blur(12px);
            box-shadow: 0 30px 60px rgba(0,0,0,0.45);
        }

        body .section h2 {
            margin: 0 0 36px 0;
            font-size: 26px;
            font-weight: 700;
            color: #ffffff;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        body .section form {
            display: flex;
            flex-direction: column;
            gap: 18px;
        }

        body .section input[type="text"] {
            height: 52px;
            padding: 0 18px;
            border-radius: 14px;
            border: none;
            background: #f9fafb;
            font-size: 15px;
            color: #333;
        }

        body .section input[type="file"] {
            height: 52px;
            padding: 12px 14px;
            border-radius: 14px;
            background: #f9fafb;
            border: none;
            font-size: 14px;
            cursor: pointer;
        }

        body .section form > br {
            display: none;
        }

        body .section .btn {
            height: 46px;
            padding: 0 32px;
            border-radius: 14px;
            font-size: 15px;
            font-weight: 600;
            background: linear-gradient(135deg, #1e88e5, #1565c0);
            color: #fff;
            border: none;
            cursor: pointer;
        }

        body .section .btn-danger {
            background: linear-gradient(135deg, #e53935, #c62828);
            margin-left: 14px;
        }

        @media (max-width: 768px) {
            .navbar {
                left: 0;
                width: 100%;
            }

            body .section {
                margin: 100px 16px !important;
            }
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="nav-left">
        <img src="<?= base_url('/assets/img/Logo.jpeg') ?>">
        <h2>SIPERAK</h2>
    </div>
    <div>
        <a href="<?= base_url('/admin') ?>">Dashboard</a>
        <a href="<?= base_url('/buku') ?>">Buku</a>
        <a href="<?= base_url('/logout') ?>">Logout</a>
    </div>
</div>

<!-- FORM -->
<div class="section">
    <h2>➕ Tambah Buku Baru</h2>

    <form action="<?= base_url('/buku/simpan') ?>" method="post" enctype="multipart/form-data">
        <input type="text" name="kode_buku" placeholder="Kode Buku" required>
        <input type="text" name="nama_buku" placeholder="Nama Buku" required>
        <input type="text" name="kategori" placeholder="Kategori Buku" required>
        <input type="file" name="cover" accept="image/*" required>

        <div>
            <button class="btn">Simpan</button>
            <a href="<?= base_url('/buku') ?>" class="btn btn-danger">Kembali</a>
        </div>
    </form>
</div>

</body>
</html>
