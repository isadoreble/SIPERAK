<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Buku Perpustakaan</title>

<link rel="stylesheet" href="<?= base_url('assets/css/dashboard.css') ?>">

<style>

/* ===== BACKGROUND ===== */
body{
    margin:0;
    background:#eef2f7;
    font-family:"Segoe UI", sans-serif;
}

/* ===== HEADER ===== */
.page-header{
    background:linear-gradient(135deg,#1e3c72,#2a5298);
    color:white;
    padding:20px 30px;
    border-radius:0 0 14px 14px;
    box-shadow:0 6px 16px rgba(0,0,0,0.15);
}

/* ===== CONTAINER ===== */
.container{
    max-width:900px;
    margin:40px auto;
    padding:20px;
}

/* ===== CARD ===== */
.card{
    background:white;
    border-radius:16px;
    padding:30px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* ===== TITLE ===== */
.card h3{
    margin-top:0;
    margin-bottom:25px;
    color:#1e3c72;
}

/* ===== FORM ===== */
.form-group{
    margin-bottom:18px;
}

label{
    display:block;
    margin-bottom:6px;
    font-weight:600;
    color:#444;
}

input{
    width:100%;
    height:45px;
    padding:0 12px;
    border-radius:8px;
    border:1px solid #d0d7e2;
    font-size:14px;
}

input:focus{
    outline:none;
    border-color:#2a5298;
}

/* ===== BUTTON AREA ===== */
.btn-area{
    margin-top:25px;
}

.btn{
    padding:11px 22px;
    border-radius:8px;
    border:none;
    cursor:pointer;
    font-size:14px;
    font-weight:bold;
}

/* SIMPAN */
.btn-save{
    background:linear-gradient(135deg,#43a047,#2e7d32);
    color:white;
}

/* KEMBALI */
.btn-back{
    background:#c62828;
    color:white;
    text-decoration:none;
    margin-left:8px;
}

.btn:hover{
    opacity:0.9;
}

</style>
</head>

<body>

<!-- HEADER -->
<div class="page-header">
    <h2>➕ Tambah Buku Perpustakaan</h2>
</div>

<div class="container">

<div class="card">

<h3>Form Tambah Buku</h3>

<form action="<?= base_url('/buku-perpus/simpan') ?>" method="post" enctype="multipart/form-data">

<div class="form-group">
<label>Kode Buku</label>
<input type="text" name="kode_buku" required>
</div>

<div class="form-group">
<label>Judul Buku</label>
<input type="text" name="judul_buku" required>
</div>

<div class="form-group">
<label>Kategori</label>
<input type="text" name="kategori" required>
</div>

<div class="form-group">
<label>Cover Buku</label>
<input type="file" name="cover" required>
</div>

<div class="btn-area">
<button type="submit" class="btn btn-save">💾 Simpan</button>
<a href="<?= base_url('/buku-perpus') ?>" class="btn btn-back">⬅ Kembali</a>
</div>

</form>

</div>
</div>

</body>
</html>
