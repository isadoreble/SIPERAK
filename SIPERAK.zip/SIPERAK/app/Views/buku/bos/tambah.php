<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Buku BOS</title>

<link rel="stylesheet" href="<?= base_url('/assets/css/dashboard.css') ?>">

<style>

/* ===== BACKGROUND ===== */
body {
    background: #f1f4f9;
    font-family: "Segoe UI", sans-serif;
}

/* ===== HEADER ===== */
.page-header {
    background: linear-gradient(135deg,#1e3c72,#2a5298);
    color: white;
    padding: 22px 30px;
    border-radius: 0 0 14px 14px;
    box-shadow: 0 6px 16px rgba(0,0,0,0.15);
    margin-bottom: 40px;
}

.page-header h2 {
    margin: 0;
}

/* ===== CARD ===== */
.section {
    max-width: 800px;
    margin: auto;
    padding: 35px;
    background: white;
    border-radius: 16px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.08);
}

/* ===== INPUT ===== */
input[type="text"],
input[type="file"] {
    width: 100%;
    height: 48px;
    margin-bottom: 18px;
    padding: 0 14px;
    border-radius: 10px;
    border: 1px solid #d0d7e2;
    font-size: 14px;
    transition: 0.2s;
}

input:focus {
    border-color: #2a5298;
    outline: none;
}

/* ===== BUTTON ===== */
.btn-save {
    background: #1e88e5;
    color: white;
    border: none;
    padding: 12px 26px;
    border-radius: 10px;
    cursor: pointer;
    font-size: 14px;
    transition: 0.2s;
}

.btn-save:hover {
    background: #1565c0;
}

.btn-back {
    margin-left: 10px;
    background: #c62828;
    color: white;
    padding: 12px 24px;
    border-radius: 10px;
    text-decoration: none;
    font-size: 14px;
}

.btn-back:hover {
    background: #a61f1f;
}

</style>
</head>

<body>

<!-- HEADER -->
<div class="page-header">
    <h2>Dashboard Admin — Tambah Buku BOS</h2>
</div>

<!-- FORM CARD -->
<div class="section">

<form action="<?= base_url('/buku-bos/simpan') ?>" method="post" enctype="multipart/form-data">

<input type="text" name="kode_buku" placeholder="Kode Buku" required>
<input type="text" name="nama_buku" placeholder="Nama Buku" required>
<input type="text" name="kategori" placeholder="Kategori" required>
<input type="file" name="cover" required>

<button type="submit" class="btn-save">Simpan</button>
<a href="<?= base_url('/buku-bos') ?>" class="btn-back">Kembali</a>

</form>

</div>

</body>
</html>
