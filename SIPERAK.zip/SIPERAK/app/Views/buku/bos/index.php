<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title><?= $judul ?></title>

<link rel="stylesheet" href="<?= base_url('assets/css/buku.css') ?>">

<style>

/* ===== BODY ===== */
body {
    margin: 0;
    background: #f1f4f9;
    font-family: "Segoe UI", sans-serif;
}

/* ===== NAVBAR ===== */
.navbar {
    background: linear-gradient(135deg,#1e3c72,#2a5298);
    color: white;
    padding: 16px 28px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
}

.navbar h1 {
    margin: 0;
    font-size: 18px;
    font-weight: bold;
}

.navbar a {
    color: white;
    text-decoration: none;
    font-size: 14px;
    background: rgba(255,255,255,0.15);
    padding: 8px 14px;
    border-radius: 8px;
    transition: 0.2s;
}

.navbar a:hover {
    background: rgba(255,255,255,0.30);
}

/* ===== CONTAINER ===== */
.container {
    max-width: 1100px;
    margin: auto;
    padding: 25px;
}

/* ===== BUTTON TAMBAH ===== */
.tambah {
    display: inline-block;
    margin-bottom: 18px;
    background: linear-gradient(135deg,#FFD700,#C9A227);
    color: white;
    font-weight: bold;
    padding: 12px 22px;
    border-radius: 10px;
    text-decoration: none;
    font-size: 14px;
    transition: 0.2s;
}

.tambah:hover {
    transform: translateY(-1px);
    opacity: 0.95;
}

/* ===== TABLE CARD ===== */
.table-card {
    background: white;
    border-radius: 14px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    overflow: hidden;
}

/* ===== HEADER TABLE AREA ===== */
.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 18px;
    background: #f7f9fc;
    border-bottom: 1px solid #e5eaf2;
}

.table-header strong {
    font-size: 15px;
}

/* tombol kembali */
.kembali {
    background: #6c757d;
    color: white;
    padding: 8px 14px;
    border-radius: 8px;
    text-decoration: none;
    font-size: 13px;
    transition: 0.2s;
}

.kembali:hover {
    background: #5a6268;
}

/* ===== TABLE WRAPPER ===== */
.table-wrapper {
    overflow-x: auto;
}

/* ===== TABLE ===== */
table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #2a5298;
    color: white;
    padding: 14px;
    text-align: left;
    font-size: 14px;
}

td {
    padding: 12px 14px;
    border-bottom: 1px solid #e0e6ef;
    font-size: 14px;
}

tr:hover {
    background: #f6f8fc;
}

/* ===== AKSI BUTTON ===== */
td a {
    text-decoration: none;
    font-size: 13px;
    margin-right: 6px;
    padding: 5px 8px;
    border-radius: 6px;
    transition: 0.2s;
}

td a:first-child {
    background: #1e88e5;
    color: white;
}

td a:first-child:hover {
    background: #1565c0;
}

td a:last-child {
    background: #e53935;
    color: white;
}

td a:last-child:hover {
    background: #c62828;
}

/* ===== EMPTY ===== */
.empty {
    text-align: center;
    padding: 20px;
    color: #777;
}

/* ===== RESPONSIVE ===== */
@media (max-width: 768px) {
    .table-header {
        flex-direction: column;
        gap: 10px;
        align-items: flex-start;
    }
}

</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h1>Data Buku BOS</h1>
    <a href="<?= base_url('/') ?>">🏠 Dashboard</a>
</div>

<div class="container">

<a href="<?= base_url('/buku-bos/tambah') ?>" class="tambah">
➕ Tambah Buku BOS
</a>

<div class="table-card">

<!-- HEADER TABLE -->
<div class="table-header">
<strong><?= $judul ?></strong>
<a href="javascript:history.back()" class="kembali">⬅ Kembali</a>
</div>

<div class="table-wrapper">

<table>

<thead>
<tr>
<th>No</th>
<th>Kode Buku</th>
<th>Judul Buku</th>
<th>Kategori</th>
<th>Aksi</th>
</tr>
</thead>

<tbody>

<?php if (!empty($buku)): ?>
<?php $no = 1; foreach ($buku as $row): ?>

<tr>
<td><?= $no++ ?></td>
<td><?= $row['kode_buku'] ?></td>
<td><?= $row['judul_buku'] ?></td>
<td><?= $row['kategori'] ?></td>
<td>
<a href="#">Edit</a>
<a href="#" onclick="return confirm('Hapus data?')">Hapus</a>
</td>
</tr>

<?php endforeach; ?>

<?php else: ?>

<tr>
<td colspan="5" class="empty">Data belum ada</td>
</tr>

<?php endif; ?>

</tbody>

</table>

</div>
</div>
</div>

</body>
</html>
