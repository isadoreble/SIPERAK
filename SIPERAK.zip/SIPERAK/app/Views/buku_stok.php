<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kelola Stok Buku</title>
<style>
body{font-family:Segoe UI, sans-serif;background:#f4f6fb;margin:0;padding:20px}
.table{width:100%;border-collapse:collapse;background:#fff;box-shadow:0 6px 18px rgba(0,0,0,0.06)}
.table th, .table td{padding:10px;border-bottom:1px solid #eee;text-align:left}
.table th{background:#1e3c72;color:#fff}
.form-inline{display:flex;gap:8px;align-items:center}
.input-stok{width:80px;padding:6px;border-radius:6px;border:1px solid #ddd}
.btn{padding:8px 10px;border-radius:6px;background:#1e3c72;color:#fff;text-decoration:none}
</style>
</head>
<body>
<h2>Kelola Stok Buku</h2>
<p><a href="<?= base_url('/admin') ?>">◀ Kembali ke Dashboard</a></p>

<div class="table-container">
<table class="table">
<thead>
<tr>
<th>#</th>
<th>Judul</th>
<th>Penulis</th>
<th>Stok</th>
<th>Aksi</th>
</tr>
</thead>
<tbody>
<?php if (!empty($buku)) : ?>
    <?php foreach ($buku as $i => $b) : ?>
    <tr>
        <td><?= $i+1 ?></td>
        <td><?= esc($b['nama_buku']) ?></td>
        <td><?= esc($b['penulis'] ?? '-') ?></td>
        <td><?= esc($b['stok'] ?? 0) ?></td>
        <td>
            <form class="form-inline" method="post" action="<?= base_url('/buku/stok/update/'.$b['id']) ?>">
                <input class="input-stok" type="number" name="stok" value="<?= esc($b['stok'] ?? 0) ?>" min="0">
                <button class="btn" type="submit">Simpan</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr><td colspan="5">Belum ada buku.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>

</body>
</html>