<?php

if (!function_exists('set_role_session')) {
    function set_role_session(string $role, array $data)
    {
        // store under namespaced key so multiple roles can coexist
        session()->set("auth_{$role}", $data);
    }
}

if (!function_exists('is_role_logged_in')) {
    function is_role_logged_in(string $role): bool
    {
        $s = session()->get("auth_{$role}");
        if (is_array($s) && !empty($s['login'])) return true;

        // Backward-compatibility: check global session keys
        if (session()->get('login') && session()->get('role') === $role) return true;

        return false;
    }
}

if (!function_exists('role_get')) {
    function role_get(string $role, string $key, $default = null)
    {
        $s = session()->get("auth_{$role}");
        if (is_array($s) && array_key_exists($key, $s)) return $s[$key];

        // Fallback to global session keys for backward compatibility
        if (session()->get('role') === $role && session()->has($key)) {
            return session()->get($key);
        }

        return $default;
    }
}

if (!function_exists('any_role_logged_in')) {
    function any_role_logged_in(array $roles = ['admin','guru','siswa']): bool
    {
        foreach ($roles as $r) {
            if (is_role_logged_in($r)) return true;
        }
        return false;
    }
}
