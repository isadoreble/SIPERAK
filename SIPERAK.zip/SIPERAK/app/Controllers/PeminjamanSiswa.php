<?php

namespace App\Controllers;

use App\Models\BukuModel;
use App\Models\PeminjamanModel;

class PeminjamanSiswa extends BaseController
{
    /*
    =========================
    LIST BUKU UNTUK SISWA
    =========================
    */
    public function index()
    {
        // proteksi login + role
        if (!is_role_logged_in('siswa')) {
            return redirect()->to('/login');
        }

        $bukuModel = new BukuModel();

        $data['buku'] = $bukuModel->findAll();

        return view('buku_view_siswa', $data);
    }

    /*
    =========================
    AJUKAN PEMINJAMAN
    =========================
    */
    public function pinjam($buku_id = null)
    {
        if (!is_role_logged_in('siswa')) {
            return redirect()->to('/login');
        }

        // Cek apakah POST (form submit dengan durasi) atau GET (confirm dialog)
        if ($this->request->getMethod() === 'post') {
            // Form POST dengan durasi
            $buku_id = $this->request->getPost('buku_id');
            $durasi = (int) $this->request->getPost('durasi') ?? 7;

            if ($durasi < 1 || $durasi > 90) {
                $durasi = 7; // Default 7 hari
            }
        } else {
            // GET request (old flow)
            $durasi = 7; // Default
        }

        if (!$buku_id) {
            return redirect()->back()->with('error', 'Buku tidak ditemukan');
        }

        $peminjamanModel = new PeminjamanModel();
        $nis = role_get('siswa', 'nis', null);
        
        if (!$nis) {
            return redirect()->back()->with('error', 'Session tidak valid. Silakan login ulang.');
        }

        // Cek apakah buku ini sedang dipinjam siswa
        if ($peminjamanModel->alreadyBorrowed($nis, $buku_id)) {
            return redirect()->back()
                ->with('error', 'Kamu sudah meminjam buku ini');
        }

        // Batasi maksimal 3 pinjaman aktif
        if ($peminjamanModel->countPinjamanAktif($nis) >= 3) {
            return redirect()->back()
                ->with('error', 'Maksimal 3 buku dalam satu waktu');
        }

        $data_pinjam = [
            'nis'            => $nis,
            'buku_id'        => $buku_id,
            'tanggal_pinjam' => date('Y-m-d'),
            'durasi_hari'    => $durasi,
            'status'         => 'Diproses'
        ];

        if (!$peminjamanModel->save($data_pinjam)) {
            // Jika save gagal, tampilkan pesan error
            $errors = $peminjamanModel->errors();
            return redirect()->back()->withInput()
                ->with('error', 'Gagal menyimpan permintaan: ' . implode(', ', $errors));
        }

        return redirect()->to('/siswa/peminjaman')
            ->with('success', 'Permintaan peminjaman berhasil dikirim. Menunggu persetujuan admin.');
    }

    /*
    =========================
    RIWAYAT PINJAMAN SISWA
    =========================
    */
    public function riwayat()
    {
        if (!is_role_logged_in('siswa')) {
            return redirect()->to('/login');
        }

        $model = new PeminjamanModel();

        $data['pinjaman'] = $model->getByNis(session()->get('nis'));

        return view('peminjaman_siswa_view', $data);
    }
}
