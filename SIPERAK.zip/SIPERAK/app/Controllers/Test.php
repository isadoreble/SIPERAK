<?php

namespace App\Controllers;

class Test extends BaseController
{
    public function index()
    {
        return "TEST OK";
    }
}
