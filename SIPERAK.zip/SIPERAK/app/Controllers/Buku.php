<?php

namespace App\Controllers;

use App\Models\BukuModel;

class Buku extends BaseController
{
    // ===============================
    // 📚 SEMUA BUKU
    // ===============================
    public function index()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $model = new BukuModel();

        $data = [
            'judul' => 'Data Buku',
            'buku'  => $model->findAll()
        ];

        return view('buku_view', $data);
    }

    public function tambah()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        return view('buku/tambah');
    }

    public function simpan()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $model = new BukuModel();

        $file = $this->request->getFile('cover');
        $namaFile = null;

        if ($file && $file->isValid()) {
            $namaFile = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads/', $namaFile);
        }

        $model->save([
            'kode_buku' => $this->request->getPost('kode_buku'),
            'nama_buku' => $this->request->getPost('nama_buku'),
            'kategori'  => $this->request->getPost('kategori'),
            'cover'     => $namaFile
        ]);

        return redirect()->to('/buku')->with('success', 'Buku berhasil ditambahkan');
    }

    public function edit($id)
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $model = new BukuModel();
        $buku = $model->find($id);

        if (!$buku) {
            return redirect()->to('/buku')->with('error', 'Data tidak ditemukan');
        }

        return view('buku_edit', ['buku' => $buku]);
    }

    public function update($id)
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $model = new BukuModel();
        $buku  = $model->find($id);

        if (!$buku) {
            return redirect()->to('/buku')->with('error', 'Data tidak ditemukan');
        }

        $file = $this->request->getFile('cover');
        $namaFile = $buku['cover'];

        if ($file && $file->isValid()) {
            $namaFile = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads/', $namaFile);

            if ($buku['cover'] && file_exists(ROOTPATH . 'public/uploads/' . $buku['cover'])) {
                unlink(ROOTPATH . 'public/uploads/' . $buku['cover']);
            }
        }

        $model->update($id, [
            'kode_buku' => $this->request->getPost('kode_buku'),
            'nama_buku' => $this->request->getPost('nama_buku'),
            'kategori'  => $this->request->getPost('kategori'),
            'cover'     => $namaFile
        ]);

        return redirect()->to('/buku')->with('success', 'Buku berhasil diperbarui');
    }

    public function hapus($id)
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $model = new BukuModel();
        $buku  = $model->find($id);

        if ($buku && $buku['cover'] && file_exists(ROOTPATH . 'public/uploads/' . $buku['cover'])) {
            unlink(ROOTPATH . 'public/uploads/' . $buku['cover']);
        }

        $model->delete($id);

        return redirect()->to('/buku')->with('success', 'Buku berhasil dihapus');
    }

    // ===============================
    // 📘 BUKU BOS
    // ===============================
    public function bos()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $model = new BukuModel();

        $data = [
            'judul' => 'Data Buku BOS',
            'buku'  => $model->where('sumber_buku', 'BOS')->findAll()
        ];

        return view('buku/bos/index', $data);
    }

    public function tambahBos()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        return view('buku/bos/tambah');
    }

    public function simpanBos()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $model = new BukuModel();

        $file = $this->request->getFile('cover');
        $namaFile = null;

        if ($file && $file->isValid()) {
            $namaFile = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads/', $namaFile);
        }

        $model->insert([
            'kode_buku'    => $this->request->getPost('kode_buku'),
            'nama_buku'    => $this->request->getPost('nama_buku'),
            'penulis'      => $this->request->getPost('penulis'),
            'penerbit'     => $this->request->getPost('penerbit'),
            'tahun_terbit' => $this->request->getPost('tahun_terbit'),
            'kategori_id'  => $this->request->getPost('kategori_id'),
            'isbn'         => $this->request->getPost('isbn'),
            'stok'         => $this->request->getPost('stok'),
            'lokasi_rak'   => $this->request->getPost('lokasi_rak'),
            'status'       => 'Tersedia',
            'sumber_buku'  => 'BOS',
            'cover'        => $namaFile
        ]);

        return redirect()->to('/buku-bos')->with('success', 'Buku BOS berhasil ditambahkan');
    }

    // ===============================
    // 📗 BUKU PERPUSTAKAAN
    // ===============================
    public function perpus()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $model = new BukuModel();

        $data = [
            'judul' => 'Data Buku Perpustakaan',
            'buku'  => $model->where('sumber_buku', 'Perpustakaan')->findAll()
        ];

        return view('buku/perpus/index', $data);
    }

    public function tambahPerpus()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        return view('buku/perpus/tambah');
    }

    public function simpanPerpus()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $model = new BukuModel();

        $file = $this->request->getFile('cover');
        $namaFile = null;

        if ($file && $file->isValid()) {
            $namaFile = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads/', $namaFile);
        }

        $model->insert([
            'kode_buku'    => $this->request->getPost('kode_buku'),
            'nama_buku'    => $this->request->getPost('nama_buku'),
            'penulis'      => $this->request->getPost('penulis'),
            'penerbit'     => $this->request->getPost('penerbit'),
            'tahun_terbit' => $this->request->getPost('tahun_terbit'),
            'kategori_id'  => $this->request->getPost('kategori_id'),
            'isbn'         => $this->request->getPost('isbn'),
            'stok'         => $this->request->getPost('stok'),
            'lokasi_rak'   => $this->request->getPost('lokasi_rak'),
            'status'       => 'Tersedia',
            'sumber_buku'  => 'Perpustakaan',
            'cover'        => $namaFile
        ]);

        return redirect()->to('/buku-perpus')->with('success', 'Buku Perpustakaan berhasil ditambahkan');
    }

    // ===============================
    // ✅ ALIAS (ANTI 404)
    // ===============================
    public function perpustakaan()
    {
        return $this->perpus();
    }

    public function tambahPerpustakaan()
    {
        return $this->tambahPerpus();
    }

    public function simpanPerpustakaan()
    {
        return $this->simpanPerpus();
    }
}
