<?php

namespace App\Controllers;

use App\Models\BukuModel;
use App\Models\PeminjamanModel;
use App\Models\UserModel;

class Dashboard extends BaseController
{

    // =============================
    // >>> TAMBAHAN MENU PINJAMAN SISWA <<<
    // =============================
    public function pinjaman()
    {
        if (!is_role_logged_in('siswa')) {
            return redirect()->to('/login');
        }

        $nis = session()->get('nis');
        $peminjamanModel = new PeminjamanModel();

        $data['pinjaman'] = [];

        try {
            $data['pinjaman'] = $peminjamanModel
                ->select('peminjaman.*, buku.nama_buku, buku.cover')
                ->join('buku', 'buku.id = peminjaman.buku_id', 'left')
                ->where('peminjaman.nis', $nis)
                ->orderBy('peminjaman.tanggal_pinjam', 'DESC')
                ->findAll();
        } catch (\Exception $e) {
            // fallback kosong
        }

        $data['namaSiswa'] = session()->get('nama');

        return view('siswa_pinjaman_view', $data);
    }

    // ===== ADMIN DASHBOARD =====
    public function admin()
    {
        if (!is_role_logged_in('admin')) {
            return redirect()->to('/login');
        }

        $bukuModel = new BukuModel();
        $peminjamanModel = new PeminjamanModel();

        $data['totalBuku'] = $bukuModel->countAll();

        $allBooks = $bukuModel->findAll();
        $kategoriCount = [];

        foreach ($allBooks as $book) {
            $kategori = $book['kategori'] ?? 'Tanpa Kategori';
            if (!isset($kategoriCount[$kategori])) {
                $kategoriCount[$kategori] = 0;
            }
            $kategoriCount[$kategori]++;
        }

        $data['kategori'] = [];
        foreach ($kategoriCount as $namaKategori => $jumlah) {
            $data['kategori'][] = [
                'kategori' => $namaKategori,
                'jumlah' => $jumlah
            ];
        }

        $data['terbaru'] = $bukuModel
            ->orderBy('created_at', 'DESC')
            ->limit(5)
            ->findAll();

        $data['peminjamanHariIni'] = $peminjamanModel
            ->where('DATE(tanggal_pinjam)', date('Y-m-d'))
            ->countAllResults();

        // Count all active borrowings (Diproses, Disetujui, Terlambat)
        $data['peminjamanAktif'] = $peminjamanModel
            ->whereIn('status', ['Diproses', 'Disetujui', 'Terlambat'])
            ->countAllResults();

        $data['peminjamanTerlambat'] = $peminjamanModel
            ->where('status', 'Terlambat')
            ->countAllResults();

        try {
            $peminjamanModel->resetQuery();

            $data['peminjamanTerbaru'] = $peminjamanModel
                ->select('peminjaman.*, u.nis, u.nama, b.nama_buku')
                ->join('users as u', 'u.nis = peminjaman.nis', 'left')
                ->join('buku as b', 'b.id = peminjaman.buku_id', 'left')
                ->orderBy('peminjaman.created_at', 'DESC')
                ->limit(6)
                ->findAll();

        } catch (\Exception $e) {

            $peminjamanModel->resetQuery();

            $data['peminjamanTerbaru'] = $peminjamanModel
                ->select('peminjaman.*, b2.nama_buku')
                ->join('buku as b2', 'b2.id = peminjaman.buku_id', 'left')
                ->orderBy('peminjaman.created_at', 'DESC')
                ->limit(6)
                ->findAll();
        }

        $grafikData = $this->getPeminjaman30HariTerakhir($peminjamanModel);
        $data['grafikLabel'] = $grafikData['labels'];
        $data['grafikData'] = $grafikData['data'];

        $db = \Config\Database::connect();
        $tables = $db->listTables();

        if (in_array('buku', $tables)) {

            $fields = $db->getFieldNames('buku');

            if (in_array('sumber_buku', $fields)) {

                $data['totalBukuBOS'] = $bukuModel
                    ->where('sumber_buku', 'BOS')
                    ->orWhere('sumber_buku', 'bos')
                    ->countAllResults();

                $data['totalBukuPerpustakaan'] = $bukuModel
                    ->where('sumber_buku', 'Perpustakaan')
                    ->orWhere('sumber_buku', 'perpustakaan')
                    ->orWhere('sumber_buku', 'Umum')
                    ->orWhere('sumber_buku', 'umum')
                    ->countAllResults();

            } else {
                $data['totalBukuBOS'] = 0;
                $data['totalBukuPerpustakaan'] = 0;
            }

        } else {
            $data['totalBukuBOS'] = 0;
            $data['totalBukuPerpustakaan'] = 0;
        }

        $data['bukuTersedia'] = $data['totalBuku'] - $data['peminjamanAktif'];

        $data['namaAdmin'] = role_get('admin', 'nama', 'Administrator');
        $data['sekolah'] = 'SMA Negeri 1 Tanjungpinang';

        return view('admin_view', $data);
    }

    // ===== SISWA DASHBOARD =====
    public function siswa()
    {
        if (!is_role_logged_in('siswa')) {
            return redirect()->to('/login');
        }

        $nis = session()->get('nis');
        $peminjamanModel = new PeminjamanModel();
        $bukuModel = new BukuModel();

        // Get all peminjaman (semua status) untuk ditampilkan di dashboard
        $data['pinjaman'] = [];

        try {
            $data['pinjaman'] = $peminjamanModel
                ->select('peminjaman.*, buku.nama_buku, buku.cover, buku.penulis')
                ->join('buku', 'buku.id = peminjaman.buku_id', 'left')
                ->where('peminjaman.nis', $nis)
                ->orderBy('peminjaman.created_at', 'DESC')
                ->findAll();
        } catch (\Exception $e) {}

        $data['riwayatPeminjaman'] = $data['pinjaman'];

        $data['bukuRekomendasi'] = $bukuModel
            ->orderBy('created_at', 'DESC')
            ->limit(5)
            ->findAll();

        $data['namaSiswa'] = role_get('siswa', 'nama', 'Siswa');
        $data['nis'] = role_get('siswa', 'nis', 'N/A');

        return view('siswa_view', $data);
    }

    private function getPeminjaman30HariTerakhir($peminjamanModel)
    {
        $labels = [];
        $data = [];

        for ($i = 29; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-$i days"));
            $labels[] = date('d M', strtotime($date));

            $count = $peminjamanModel
                ->where('DATE(tanggal_pinjam)', $date)
                ->countAllResults();

            $data[] = $count;
        }

        return [
            'labels' => $labels,
            'data' => $data
        ];
    }

    public function index()
    {
        if (any_role_logged_in()) {

            // prefer global role if present, otherwise pick any logged role
            $role = session()->get('role') ?: (is_role_logged_in('admin') ? 'admin' : (is_role_logged_in('guru') ? 'guru' : (is_role_logged_in('siswa') ? 'siswa' : null)));

            switch ($role) {
                case 'admin': return redirect()->to('/admin');
                case 'guru': return redirect()->to('/guru');
                case 'siswa': return redirect()->to('/siswa');
            }
        }

        return redirect()->to('/login');
    }
}
