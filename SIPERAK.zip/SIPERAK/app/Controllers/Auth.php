<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
    {
        return view('login_view');
    }

    public function proses()
    {
        $model = new UserModel();

        $username = trim($this->request->getPost('username'));
        $password = trim((string)$this->request->getPost('password'));

        if ($username === '' || $password === '') {
            return redirect()->back()->with('error', 'Username dan Password wajib diisi!');
        }

        $user = $model->where('username', $username)->first();

        if (!$user) {
            return redirect()->back()->with('error', 'Username tidak ditemukan!');
        }

        if (hash('sha256', $password) !== $user['password']) {
            return redirect()->back()->with('error', 'Password salah!');
        }

        $sessionData = [
            'login'    => true,
            'user_id'  => $user['id'],
            'username' => $user['username'],
            'nama'     => $user['nama'],
            'nis'      => $user['nis'] ?? null,
            'kelas'    => $user['kelas'] ?? null,
            'role'     => $user['role']
        ];

        // If there's already a different active global login, store this login under role-scoped key
        $currentRole = session()->get('role');
        if ($currentRole && $currentRole !== $user['role']) {
            set_role_session($user['role'], $sessionData);
        } else {
            // No conflicting active role: keep backward-compatible global session
            session()->set($sessionData);
        }

        switch ($user['role']) {
            case 'admin':
                return redirect()->to('/admin');
            case 'guru':
                return redirect()->to('/guru');
            case 'siswa':
                return redirect()->to('/siswa');
            default:
                session()->destroy();
                return redirect()->to('/login')->with('error', 'Role tidak valid!');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}