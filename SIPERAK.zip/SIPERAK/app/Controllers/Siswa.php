<?php

namespace App\Controllers;

use App\Models\PeminjamanModel;

class Siswa extends BaseController
{
    public function index()
    {
        $model = new PeminjamanModel();

        $nis = role_get('siswa', 'nis', session()->get('nis'));

        $data['pinjaman'] = $model->getPinjamanSiswa($nis);

        return view('siswa_view', $data);
    }
}
