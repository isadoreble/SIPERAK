<?php

namespace App\Controllers;

class Perpustakaan extends BaseController
{
    public function index()
    {
        return view('perpustakaan/index');
    }
}
