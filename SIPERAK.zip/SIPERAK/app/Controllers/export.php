<?php

namespace App\Controllers;
use App\Models\BukuModel;

class Export extends BaseController
{
    public function pdf()
    {
        $model = new BukuModel();
        $data['buku'] = $model->findAll();

        return view('export_pdf', $data);
    }

    public function excel()
    {
        $model = new BukuModel();
        $data['buku'] = $model->findAll();

        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=data_buku.xls");

        return view('export_excel', $data);
    }
}
