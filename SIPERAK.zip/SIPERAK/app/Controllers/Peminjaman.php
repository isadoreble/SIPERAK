<?php

namespace App\Controllers;

use App\Models\PeminjamanModel;

class Peminjaman extends BaseController
{
    public function index()
    {
        if (!is_role_logged_in('admin') && !is_role_logged_in('petugas')) {
            return redirect()->to('/login');
        }

        $model = new PeminjamanModel();

        $data['peminjaman'] = $model->getAllWithDetail();

        return view('peminjaman_index', $data);
    }

    public function setujui($id)
    {
        if (!is_role_logged_in('admin') && !is_role_logged_in('petugas')) {
            return redirect()->to('/login');
        }

        $model = new PeminjamanModel();

        $pinjam = $model->find($id);
        if (!$pinjam) {
            return redirect()->back()->with('error', 'Data peminjaman tidak ditemukan');
        }

        // Hitung tanggal kembali berdasarkan durasi yang dipilih siswa
        $durasi = isset($pinjam['durasi_hari']) ? (int) $pinjam['durasi_hari'] : 7;
        $tanggal_kembali = date('Y-m-d', strtotime("+{$durasi} days", strtotime($pinjam['tanggal_pinjam'])));

        $model->update($id, [
            'status' => 'Disetujui',
            'tanggal_kembali' => $tanggal_kembali
        ]);

        return redirect()->back()->with('success', 'Permintaan disetujui');
    }

    public function tolak($id)
    {
        if (!is_role_logged_in('admin') && !is_role_logged_in('petugas')) {
            return redirect()->to('/login');
        }

        $model = new PeminjamanModel();
        $model->update($id, ['status' => 'Ditolak']);

        return redirect()->back()->with('success', 'Permintaan ditolak');
    }

    public function kembali($id)
    {
        if (!is_role_logged_in('admin') && !is_role_logged_in('petugas')) {
            return redirect()->to('/login');
        }

        $model = new PeminjamanModel();

        $pinjam = $model->find($id);
        if (!$pinjam) {
            return redirect()->back()->with('error', 'Data peminjaman tidak ditemukan');
        }

        $model->update($id, [
            'status' => 'Kembali',
            'tanggal_kembali' => date('Y-m-d')
        ]);

        return redirect()->back()->with('success', 'Buku ditandai telah dikembalikan');
    }

    // optional: simple endpoint to mark overdue statuses — keep basic
    public function updateStatus()
    {
        if (!is_role_logged_in('admin') && !is_role_logged_in('petugas')) {
            return redirect()->to('/login');
        }

        $model = new PeminjamanModel();

        // set status to 'Terlambat' for entries past tanggal_kembali and still Disetujui
        $today = date('Y-m-d');

        $db = \Config\Database::connect();
        $db->query("UPDATE peminjaman SET status = 'Terlambat' WHERE status = 'Disetujui' AND tanggal_kembali < ?", [$today]);

        return redirect()->back()->with('success', 'Status diperbarui');
    }
}
