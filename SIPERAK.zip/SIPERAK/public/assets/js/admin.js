// Highlight menu aktif
document.querySelectorAll('.sidebar a').forEach(link => {
    if (link.href === window.location.href) {
        link.classList.add('active');
        
    }
});

// Dark Mode Toggle
function toggleMode() {
    document.body.classList.toggle('light');
    localStorage.setItem('mode', document.body.classList.contains('light') ? 'light' : 'dark');
}

// Load Mode
if (localStorage.getItem('mode') === 'light') {
    document.body.classList.add('light');
}